/* ============================================================
   storage.js — single source of truth, persisted to localStorage
   Collections: buys, sells, expenses, audit
   Config: settings, lists (assets/banks/modes/categories), admin
   ============================================================ */
'use strict';

const Store = {
  KEY: 'p2pLedger.v1',

  data: null,

  DEFAULTS: {
    buys: [],       // {id,date,party,asset,fees,qty,price,netQty,bank,mode,utr,orderNo,notes,total,tags,fav,createdAt}
    sells: [],
    expenses: [],   // {id,date,name,category,amount,description}
    audit: [],      // {ts,action,detail}
    settings: {
      theme: 'dark',
      accentColor: '#22c7a9',
      font: "'Segoe UI', system-ui, sans-serif",
      fontSize: 15,
      currencySymbol: '₹',
      dateFormat: 'DD/MM/YYYY',
      numberFormat: 'indian',
      defaultAsset: 'USDT',
      defaultBank: '',
      defaultMode: 'UPI',
      autoSave: true,
      autoBackup: false,
      animations: true,
      pinnedFilters: {},        // per-page saved filter values
    },
    lists: {
      assets: ['USDT', 'BTC', 'ETH', 'USDC'],
      banks: ['HDFC Bank', 'ICICI Bank', 'SBI', 'Axis Bank'],
      modes: ['UPI', 'IMPS', 'NEFT', 'RTGS', 'Cash', 'Wallet Transfer'],
      expenseCategories: ['Office', 'Travel', 'Internet', 'Electricity', 'Exchange Fees', 'Bank Charges', 'Salary', 'Miscellaneous'],
      favBanks: [], favAssets: [],
    },
    admin: {
      password: 'admin',            // change in Admin Panel
      profitFormula: 'sell-buy',    // legacy — superseded by formulas.grossProfit
      customFormula: 'sell - buy',  // legacy
      formulas: {},                 // id → custom expression (see formulas.js)
      hiddenCards: [],              // dashboard card ids to hide
      cardOrder: [],                // dashboard card order
      disabledReports: [],          // e.g. ['tax','profit']
      hiddenSections: [],
    },
  },

  /* ---------- lifecycle ---------- */
  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      this.data = raw ? JSON.parse(raw) : structuredClone(this.DEFAULTS);
    } catch { this.data = structuredClone(this.DEFAULTS); }
    // merge in any new default keys after upgrades
    this.data.settings = { ...this.DEFAULTS.settings, ...this.data.settings };
    this.data.lists = { ...structuredClone(this.DEFAULTS.lists), ...this.data.lists };
    this.data.admin = { ...this.DEFAULTS.admin, ...this.data.admin };
    ['buys', 'sells', 'expenses', 'audit'].forEach(k => { if (!Array.isArray(this.data[k])) this.data[k] = []; });
  },

  save() {
    try {
      localStorage.setItem(this.KEY, JSON.stringify(this.data));
      const dot = document.getElementById('autosaveDot');
      if (dot) { dot.classList.add('on'); setTimeout(() => dot.classList.remove('on'), 900); }
    } catch (e) {
      U.toast('Storage full — export a backup and clear old data', true);
    }
  },

  /* debounced autosave used by modules after edits */
  autoSave: null, // assigned below

  /* ---------- accessors ---------- */
  settings() { return this.data?.settings || this.DEFAULTS.settings; },
  lists() { return this.data.lists; },
  admin() { return this.data.admin; },
  buys() { return this.data.buys; },
  sells() { return this.data.sells; },
  expenses() { return this.data.expenses; },

  /* ---------- audit log ---------- */
  log(action, detail) {
    this.data.audit.unshift({ ts: new Date().toISOString(), action, detail });
    if (this.data.audit.length > 500) this.data.audit.length = 500;
  },

  /* ---------- duplicate detection ----------
     A transaction is considered duplicate if the UTR or Binance order number matches (non-empty),
     or date+amount+party all match an existing record. */
  isDuplicate(kind, tx, ignoreId = null) {
    const list = kind === 'buy' ? this.buys() : this.sells();
    return list.some(t => {
      if (t.id === ignoreId) return false;
      if (tx.utr && t.utr && t.utr.trim() === tx.utr.trim()) return true;
      if (tx.orderNo && t.orderNo && t.orderNo.trim() === tx.orderNo.trim()) return true;
      return t.date === tx.date &&
        U.round2(t.total) === U.round2(tx.total) &&
        (t.party || '').trim().toLowerCase() === (tx.party || '').trim().toLowerCase();
    });
  },

  /* ---------- backup / restore ---------- */
  exportData() { return JSON.stringify(this.data); },

  importData(json, silent = false) {
    const incoming = typeof json === 'string' ? JSON.parse(json) : json;
    this.data = incoming;
    this.load2();
    this.save();
    if (!silent) { this.log('restore', 'Data restored from backup'); U.toast('Backup restored'); }
  },

  load2() { // re-apply defaults merge after import
    this.data.settings = { ...this.DEFAULTS.settings, ...this.data.settings };
    this.data.lists = { ...structuredClone(this.DEFAULTS.lists), ...this.data.lists };
    this.data.admin = { ...this.DEFAULTS.admin, ...this.data.admin };
    ['buys', 'sells', 'expenses', 'audit'].forEach(k => { if (!Array.isArray(this.data[k])) this.data[k] = []; });
  },

  resetAll() {
    this.data = structuredClone(this.DEFAULTS);
    this.save();
  },
};

Store.load();
Store.autoSave = U.debounce(() => { if (Store.settings().autoSave) Store.save(); }, 1500);

/* Periodic safety save every 20s + on tab close */
setInterval(() => Store.save(), 20000);
window.addEventListener('beforeunload', () => Store.save());
