/* ============================================================
   charts.js — Chart.js helpers. All dashboard charts live here.
   Gracefully no-ops if Chart.js failed to load (offline w/o lib).
   ============================================================ */
'use strict';

const Charts = {
  instances: {},

  ok() { return typeof Chart !== 'undefined'; },

  palette() {
    const s = Store.settings();
    const accent = s.accentColor || '#22c7a9';
    return [accent, '#7aa2ff', '#f5b455', '#ff6b7a', '#b48cff', '#5ad1e6', '#8bd450', '#ff9ecb'];
  },

  baseOpts() {
    const dark = Store.settings().theme !== 'light';
    const grid = dark ? 'rgba(255,255,255,0.07)' : 'rgba(30,45,70,0.08)';
    const tick = dark ? '#92a0b8' : '#5d6b84';
    return {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: tick, boxWidth: 12, font: { size: 11 } } } },
      scales: {
        x: { grid: { color: grid }, ticks: { color: tick, maxRotation: 45, font: { size: 10 } } },
        y: { grid: { color: grid }, ticks: { color: tick, font: { size: 10 } } },
      },
    };
  },

  /* Create or replace a chart on a canvas id */
  draw(id, config) {
    if (!this.ok()) return;
    const canvas = document.getElementById(id);
    if (!canvas) return;
    if (this.instances[id]) this.instances[id].destroy();
    this.instances[id] = new Chart(canvas.getContext('2d'), config);
  },

  destroyAll() {
    Object.values(this.instances).forEach(c => c.destroy());
    this.instances = {};
  },

  /* ---------- specific chart builders (data comes from Dashboard) ---------- */

  line(id, labels, datasets) {
    const pal = this.palette();
    this.draw(id, {
      type: 'line',
      data: {
        labels,
        datasets: datasets.map((d, i) => ({
          ...d, borderColor: pal[i % pal.length], tension: .35, pointRadius: 2,
          backgroundColor: pal[i % pal.length] + '33', fill: d.fill ?? false, borderWidth: 2,
        })),
      },
      options: this.baseOpts(),
    });
  },

  bars(id, labels, datasets, stacked = false) {
    const pal = this.palette();
    const opts = this.baseOpts();
    if (stacked) { opts.scales.x.stacked = true; opts.scales.y.stacked = true; }
    this.draw(id, {
      type: 'bar',
      data: {
        labels,
        datasets: datasets.map((d, i) => ({
          ...d, backgroundColor: (d.colors || pal[i % pal.length] + 'cc'), borderRadius: 6,
        })),
      },
      options: opts,
    });
  },

  pie(id, labels, values, doughnut = false) {
    const pal = this.palette();
    this.draw(id, {
      type: doughnut ? 'doughnut' : 'pie',
      data: { labels, datasets: [{ data: values, backgroundColor: labels.map((_, i) => pal[i % pal.length] + 'dd'), borderWidth: 0 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'right', labels: { color: this.baseOpts().scales.x.ticks.color, boxWidth: 12, font: { size: 11 } } } },
      },
    });
  },

  area(id, labels, label, values) {
    const pal = this.palette();
    this.draw(id, {
      type: 'line',
      data: { labels, datasets: [{ label, data: values, borderColor: pal[0], backgroundColor: pal[0] + '33', fill: true, tension: .3, pointRadius: 0, borderWidth: 2 }] },
      options: this.baseOpts(),
    });
  },
};
