/* ============================================================
   app.js — bootstrap, navigation, global search, shortcuts,
   quick-entry FAB, floating calculator & notes
   ============================================================ */
'use strict';

const App = {
  current: 'dashboard',
  pages: {
    dashboard: () => Dashboard.render(),
    buy: () => Buy.render(),
    sell: () => Sell.render(),
    profit: () => Profit.render(),
    summary: () => Summary.render(),
    expenses: () => Expenses.render(),
    tax: () => Tax.render(),
    excel: () => Excel.render(),
    settings: () => Settings.render(),
    admin: () => Admin.render(),
  },

  go(page) {
    this.current = page;
    document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === page));
    document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + page));
    document.getElementById('sidebar').classList.remove('open');
    this.pages[page]();
  },

  refreshAll() {
    Settings.applyAll();
    this.pages[this.current]();
    if (this.current !== 'dashboard') Dashboard.refresh();
  },

  /* ---------- global search across everything ---------- */
  globalSearch(q) {
    const box = document.getElementById('searchResults');
    q = q.trim().toLowerCase();
    if (!q) { box.hidden = true; return; }

    const hits = [];
    const scan = (list, kind) => list.forEach(t => {
      const hay = [t.party, t.asset, t.bank, t.mode, t.utr, t.orderNo, t.notes, t.date,
        String(t.total), String(t.price), ...(t.tags || [])].join(' ').toLowerCase();
      if (hay.includes(q)) hits.push({ kind, t });
    });
    scan(Store.buys(), 'Buy');
    scan(Store.sells(), 'Sell');
    Store.expenses().forEach(t => {
      if ([t.name, t.category, t.description, t.date, String(t.amount)].join(' ').toLowerCase().includes(q))
        hits.push({ kind: 'Expense', t });
    });

    box.innerHTML = hits.slice(0, 12).map(h => `
      <div class="search-hit" data-kind="${h.kind}" data-id="${h.t.id}">
        <span><span class="tag">${h.kind}</span> ${U.esc(h.t.party || h.t.name)}</span>
        <span class="dim">${U.fmtDate(h.t.date)} · ${U.fmtMoney(h.t.total ?? h.t.amount)}</span>
      </div>`).join('') || '<div class="search-hit"><span class="dim">No matches</span></div>';
    box.hidden = false;

    box.querySelectorAll('.search-hit[data-id]').forEach(el => el.onclick = () => {
      box.hidden = true;
      document.getElementById('globalSearch').value = '';
      const { kind, id } = el.dataset;
      if (kind === 'Buy') { this.go('buy'); Buy.edit(id); }
      else if (kind === 'Sell') { this.go('sell'); Sell.edit(id); }
      else { this.go('expenses'); Expenses.edit(id); }
    });
  },

  /* ---------- floating calculator & notes ---------- */
  makeDraggable(el, handle) {
    let sx, sy, ox, oy;
    handle.onpointerdown = e => {
      sx = e.clientX; sy = e.clientY;
      const r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
      const move = ev => {
        el.style.left = ox + ev.clientX - sx + 'px';
        el.style.top = oy + ev.clientY - sy + 'px';
        el.style.right = 'auto'; el.style.bottom = 'auto';
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    };
  },

  toggleCalc() {
    let el = document.getElementById('floatCalc');
    if (el) return el.remove();
    el = U.el('div', { id: 'floatCalc', class: 'float-tool', style: 'right:100px;bottom:100px' });
    el.innerHTML = `
      <header><span>🧮 Calculator</span><button class="icon-btn" id="calcClose">✕</button></header>
      <input class="calc-display" id="calcDisplay" readonly value="0">
      <div class="calc-keys">
        ${['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', 'C', '+', '(', ')', '⌫', '='].map(k => `<button data-k="${k}">${k}</button>`).join('')}
      </div>`;
    document.body.appendChild(el);
    this.makeDraggable(el, el.querySelector('header'));
    const disp = el.querySelector('#calcDisplay');
    let expr = '';
    el.querySelectorAll('[data-k]').forEach(b => b.onclick = () => {
      const k = b.dataset.k;
      if (k === 'C') expr = '';
      else if (k === '⌫') expr = expr.slice(0, -1);
      else if (k === '=') {
        if (/^[\d+\-*/(). ]+$/.test(expr)) {
          try { expr = String(U.round2(Function('"use strict";return (' + expr + ')')())); }
          catch { expr = 'Error'; }
        }
      } else expr += k;
      disp.value = expr || '0';
    });
    el.querySelector('#calcClose').onclick = () => el.remove();
  },

  toggleNotes() {
    let el = document.getElementById('floatNotes');
    if (el) return el.remove();
    el = U.el('div', { id: 'floatNotes', class: 'float-tool', style: 'right:100px;bottom:100px' });
    el.innerHTML = `
      <header><span>📝 Scratch notes</span><button class="icon-btn" id="notesClose">✕</button></header>
      <textarea id="notesArea" class="calc-display" style="text-align:left;font-size:.9rem"
        placeholder="Quick notes — saved automatically">${U.esc(localStorage.getItem('p2pLedger.notes') || '')}</textarea>`;
    document.body.appendChild(el);
    this.makeDraggable(el, el.querySelector('header'));
    el.querySelector('#notesArea').addEventListener('input',
      U.debounce(e => localStorage.setItem('p2pLedger.notes', e.target.value), 400));
    el.querySelector('#notesClose').onclick = () => el.remove();
  },

  /* ---------- init ---------- */
  init() {
    Settings.applyAll();

    // nav
    document.querySelectorAll('.nav-item').forEach(b => b.onclick = () => this.go(b.dataset.page));
    document.getElementById('hamburger').onclick = () => document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('themeToggle').onclick = () => {
      const s = Store.settings();
      s.theme = s.theme === 'dark' ? 'light' : 'dark';
      Store.save();
      Settings.applyAll();
      this.refreshAll();
    };

    // global search
    const gs = document.getElementById('globalSearch');
    gs.addEventListener('input', U.debounce(e => this.globalSearch(e.target.value), 200));
    document.addEventListener('click', e => {
      if (!e.target.closest('.global-search')) document.getElementById('searchResults').hidden = true;
    });

    // quick entry FAB → jump to Buy form
    document.getElementById('fab').onclick = () => {
      this.go('buy');
      setTimeout(() => document.getElementById('buyParty')?.focus(), 100);
    };

    // clock chip
    const clock = () => document.getElementById('clockChip').textContent =
      new Date().toLocaleString(undefined, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    clock();
    setInterval(clock, 30000);

    // keyboard shortcuts
    document.addEventListener('keydown', e => {
      const mod = e.ctrlKey || e.metaKey;
      const typing = /input|textarea|select/i.test(document.activeElement?.tagName || '');
      if (mod && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); e.shiftKey ? History.redo() : History.undo(); }
      else if (mod && e.key.toLowerCase() === 'y' && !typing) { e.preventDefault(); History.redo(); }
      else if (mod && e.key.toLowerCase() === 'n') { e.preventDefault(); this.go('buy'); setTimeout(() => document.getElementById('buyParty')?.focus(), 80); }
      else if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); gs.focus(); }
      else if (mod && e.key.toLowerCase() === 'b') { e.preventDefault(); this.toggleCalc(); }
      else if (mod && e.key.toLowerCase() === 'm') { e.preventDefault(); this.toggleNotes(); }
      else if (e.key === 'Escape') { document.getElementById('searchResults').hidden = true; }
      else if (!typing && !mod) {
        const jump = { 1: 'dashboard', 2: 'buy', 3: 'sell', 4: 'profit', 5: 'summary', 6: 'expenses', 7: 'tax', 8: 'excel', 9: 'settings', 0: 'admin' }[e.key];
        if (jump) this.go(jump);
      }
    });

    // weekly backup reminder
    if (Store.settings().autoBackup) {
      const last = +localStorage.getItem('p2pLedger.lastBackupNudge') || 0;
      if (Date.now() - last > 7 * 86400000) {
        setTimeout(() => {
          U.toast('Weekly reminder: download a backup from Import/Export');
          localStorage.setItem('p2pLedger.lastBackupNudge', String(Date.now()));
        }, 2500);
      }
    }

    // library availability notices (offline without CDN copies)
    if (typeof Chart === 'undefined')
      setTimeout(() => U.toast('Charts library not loaded — save chart.umd.js locally for offline charts', true), 1200);

    this.go('dashboard');
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
