/* ============================================================
   effects.js — visual extras controlled from Admin → Glow / Background
   • Glow: neon-style glow on cards, buttons, logo, titles, sidebar
   • Flying USDT & Bitcoin icons drifting up behind the app
   Both are pure decoration: pointer-events none, paused when the
   tab is hidden, and static when animations are off / reduced motion.
   ============================================================ */
'use strict';

const Effects = {

  DEF: {
    glow: { enabled: true, color: '#b44dff', intensity: 45, cards: true, buttons: true, logo: true, titles: false, sidebar: false, pulse: false },
    bgIcons: { enabled: true, set: 'both', count: 16, speed: 4, opacity: 22, size: 36 },
  },

  /* config with defaults filled in (stored inside Admin settings) */
  cfg(kind) {
    const A = Store.admin();
    A[kind] = { ...this.DEF[kind], ...(A[kind] || {}) };
    return A[kind];
  },

  apply() { this.applyGlow(); this.bgSync(); },

  /* ---------- glow ---------- */
  applyGlow() {
    const g = this.cfg('glow');
    const root = document.documentElement.style;
    root.setProperty('--glow-color', g.color);
    root.setProperty('--glow-size', (4 + g.intensity * 0.36).toFixed(1) + 'px');
    root.setProperty('--glow-mix', (25 + g.intensity * 0.55).toFixed(0) + '%');
    const b = document.body.classList;
    b.toggle('glow-on', !!g.enabled);
    ['cards', 'buttons', 'logo', 'titles', 'sidebar', 'pulse'].forEach(k => b.toggle('glow-' + k, !!g[k]));
  },

  /* ---------- flying icons ---------- */
  bg: { canvas: null, ctx: null, items: [], sprites: null, raf: 0, last: 0, key: '', w: 0, h: 0, dpr: 1 },

  /* Sprites are drawn with paths (no font dependency) at 128px, scaled when painted */
  makeSprites() {
    const mk = draw => {
      const c = document.createElement('canvas'); c.width = c.height = 128;
      const x = c.getContext('2d'); draw(x); return c;
    };
    const coin = (x, fill) => {
      x.beginPath(); x.arc(64, 64, 60, 0, Math.PI * 2); x.fillStyle = fill; x.fill();
      x.lineWidth = 5; x.strokeStyle = 'rgba(255,255,255,.55)';
      x.beginPath(); x.arc(64, 64, 53, 0, Math.PI * 2); x.stroke();
    };
    return {
      usdt: mk(x => {
        coin(x, '#26a17b');
        x.fillStyle = '#fff';
        x.fillRect(34, 36, 60, 14);           // top bar of T
        x.fillRect(56, 44, 16, 50);           // stem
        x.lineWidth = 5; x.strokeStyle = '#fff';
        x.beginPath(); x.ellipse(64, 50, 38, 10, 0, 0, Math.PI * 2); x.stroke(); // Tether ring
      }),
      btc: mk(x => {
        coin(x, '#f7931a');
        x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'alphabetic';
        x.font = 'bold 76px Arial, Helvetica, sans-serif';
        x.fillText('B', 64, 92);
        x.lineWidth = 6; x.strokeStyle = '#fff'; x.lineCap = 'round';
        [50, 66].forEach(px => {               // Bitcoin's two vertical ticks
          x.beginPath(); x.moveTo(px, 26); x.lineTo(px, 38); x.stroke();
          x.beginPath(); x.moveTo(px, 92); x.lineTo(px, 104); x.stroke();
        });
      }),
    };
  },

  bgSync() {
    const c = this.cfg('bgIcons');
    const bg = this.bg;
    if (!bg.canvas) {
      bg.canvas = document.createElement('canvas');
      bg.canvas.id = 'bgIcons';
      bg.canvas.setAttribute('aria-hidden', 'true');
      document.body.prepend(bg.canvas);
      bg.ctx = bg.canvas.getContext('2d');
      window.addEventListener('resize', U.debounce(() => { this.bgResize(); this.bgSync(); }, 200));
    }
    cancelAnimationFrame(bg.raf); bg.raf = 0;
    bg.canvas.style.display = c.enabled ? 'block' : 'none';
    if (!c.enabled) return;

    if (!bg.sprites) bg.sprites = this.makeSprites();
    this.bgResize();

    // rebuild the icon population only when its shape changes
    const narrow = window.innerWidth < 700;
    const count = Math.round(c.count * (narrow ? 0.6 : 1));
    const key = [c.set, count, c.size, bg.w, bg.h].join('|');
    if (key !== bg.key) {
      bg.key = key;
      const types = c.set === 'usdt' ? ['usdt'] : c.set === 'btc' ? ['btc'] : ['usdt', 'btc'];
      bg.items = Array.from({ length: count }, (_, i) => this.spawn(types[i % types.length], true));
    }

    const still = !Store.settings().animations || matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (still) { this.bgDraw(0); return; }
    bg.last = performance.now();
    const loop = now => {
      const dt = Math.min(0.05, (now - bg.last) / 1000); bg.last = now;
      this.bgDraw(dt);
      bg.raf = requestAnimationFrame(loop);
    };
    bg.raf = requestAnimationFrame(loop);
  },

  bgResize() {
    const bg = this.bg;
    bg.dpr = Math.min(2, window.devicePixelRatio || 1);
    bg.w = window.innerWidth; bg.h = window.innerHeight;
    bg.canvas.width = Math.round(bg.w * bg.dpr);
    bg.canvas.height = Math.round(bg.h * bg.dpr);
  },

  spawn(type, anywhere) {
    const c = this.cfg('bgIcons');
    const s = 0.55 + Math.random() * 0.9;                 // depth: small = far, large = near
    return {
      type, s,
      x0: Math.random() * this.bg.w,
      y: anywhere ? Math.random() * this.bg.h : this.bg.h + c.size * s,
      vy: (0.6 + Math.random() * 0.8) * (0.5 + s * 0.5),  // near icons drift faster
      amp: 10 + Math.random() * 28, freq: 0.3 + Math.random() * 0.5,
      phase: Math.random() * Math.PI * 2,
      rot: (Math.random() - 0.5) * 0.5,
      a: 0.5 + Math.random() * 0.5,
    };
  },

  bgDraw(dt) {
    const { ctx, canvas, items, sprites, dpr, h } = this.bg;
    const c = this.cfg('bgIcons');
    const t = performance.now() / 1000;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.scale(dpr, dpr);

    items.forEach((it, i) => {
      it.y -= dt * c.speed * 14 * it.vy;                 // px/sec scaled by the speed slider
      const size = c.size * it.s;
      if (it.y < -size) Object.assign(it, this.spawn(it.type, false), { x0: Math.random() * this.bg.w });
      const x = it.x0 + Math.sin(t * it.freq + it.phase) * it.amp;
      ctx.save();
      ctx.globalAlpha = (c.opacity / 100) * it.a;
      ctx.translate(x, it.y);
      ctx.rotate(Math.sin(t * it.freq * 0.8 + it.phase) * it.rot);
      ctx.drawImage(sprites[it.type], -size / 2, -size / 2, size, size);
      ctx.restore();
    });
  },
};
