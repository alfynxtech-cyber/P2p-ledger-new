/* ============================================================
   utils.js — shared helpers used by every module
   ============================================================ */
'use strict';

const U = {

  /* ---------- ids & misc ---------- */
  uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); },

  clamp(n, a, b) { return Math.min(b, Math.max(a, n)); },

  round2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; },

  num(v) { const n = parseFloat(v); return isFinite(n) ? n : 0; },

  debounce(fn, ms) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  },

  esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  },

  /* ---------- number & currency formatting (settings-aware) ---------- */
  fmtNum(n, decimals = 2) {
    const s = Store.settings();
    const val = Number(n) || 0;
    const locale = s.numberFormat === 'international' ? 'en-US' : 'en-IN';
    return val.toLocaleString(locale, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  },

  fmtMoney(n, decimals = 2) {
    const s = Store.settings();
    return (s.currencySymbol || '₹') + this.fmtNum(n, decimals);
  },

  /* ---------- dates ---------- */
  todayISO() { return new Date().toISOString().slice(0, 10); },

  fmtDate(iso) {
    if (!iso) return '';
    const s = Store.settings();
    const [y, m, d] = iso.split('-');
    switch (s.dateFormat) {
      case 'MM/DD/YYYY': return `${m}/${d}/${y}`;
      case 'YYYY-MM-DD': return iso;
      default: return `${d}/${m}/${y}`; // DD/MM/YYYY
    }
  },

  monthKey(iso) { return iso ? iso.slice(0, 7) : ''; },
  yearKey(iso) { return iso ? iso.slice(0, 4) : ''; },

  quarterKey(iso) {
    if (!iso) return '';
    const m = parseInt(iso.slice(5, 7), 10);
    return iso.slice(0, 4) + '-Q' + Math.ceil(m / 3);
  },

  weekKey(iso) {
    // ISO week number key like 2026-W05
    const d = new Date(iso + 'T12:00:00');
    const day = (d.getUTCDay() + 6) % 7;
    d.setUTCDate(d.getUTCDate() - day + 3);
    const firstThu = new Date(Date.UTC(d.getUTCFullYear(), 0, 4));
    const week = 1 + Math.round(((d - firstThu) / 86400000 - 3 + ((firstThu.getUTCDay() + 6) % 7)) / 7);
    return d.getUTCFullYear() + '-W' + String(week).padStart(2, '0');
  },

  // Indian financial year: Apr 1 – Mar 31. "2025-26" for 2025-04-01..2026-03-31
  fyKey(iso) {
    if (!iso) return '';
    const y = parseInt(iso.slice(0, 4), 10);
    const m = parseInt(iso.slice(5, 7), 10);
    const start = m >= 4 ? y : y - 1;
    return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
  },

  fyRange(fy) {
    // fy like "2025-26" -> [startISO, endISO]
    const start = parseInt(fy.slice(0, 4), 10);
    return [`${start}-04-01`, `${start + 1}-03-31`];
  },

  inRange(iso, from, to) {
    if (from && iso < from) return false;
    if (to && iso > to) return false;
    return true;
  },

  /* ---------- toast, confirm ---------- */
  toast(msg, isErr = false) {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.classList.toggle('err', isErr);
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 2600);
  },

  confirm(msg, yesLabel = 'Delete') {
    return new Promise(resolve => {
      const dlg = document.getElementById('confirmDialog');
      document.getElementById('confirmMsg').textContent = msg;
      const yes = document.getElementById('confirmYes');
      yes.textContent = yesLabel;
      const no = document.getElementById('confirmNo');
      const done = ok => { dlg.close(); yes.onclick = no.onclick = null; resolve(ok); };
      yes.onclick = () => done(true);
      no.onclick = () => done(false);
      dlg.showModal();
    });
  },

  /* ---------- DOM ---------- */
  el(tag, attrs = {}, html = '') {
    const e = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
    if (html) e.innerHTML = html;
    return e;
  },

  optionList(items, selected) {
    return items.map(i => `<option value="${this.esc(i)}" ${i === selected ? 'selected' : ''}>${this.esc(i)}</option>`).join('');
  },

  /* ---------- generic sortable / paginated table ----------
     cfg: { columns:[{key,label,num,render}], rows, pageSize, onRowClick, actions(row) }   */
  renderTable(container, cfg) {
    const state = container._tState ||= { sortKey: cfg.defaultSort || null, sortDir: -1, page: 1 };
    let rows = [...cfg.rows];

    if (state.sortKey) {
      rows.sort((a, b) => {
        const av = a[state.sortKey], bv = b[state.sortKey];
        if (av === bv) return 0;
        return (av > bv ? 1 : -1) * state.sortDir;
      });
    }

    const pageSize = cfg.pageSize || 15;
    const pages = Math.max(1, Math.ceil(rows.length / pageSize));
    state.page = U.clamp(state.page, 1, pages);
    const pageRows = rows.slice((state.page - 1) * pageSize, state.page * pageSize);

    const head = cfg.columns.map(c =>
      `<th class="${c.num ? 'num' : ''}" data-key="${c.key}">${c.label}` +
      (state.sortKey === c.key ? `<span class="sort-arrow">${state.sortDir === 1 ? '▲' : '▼'}</span>` : '') +
      `</th>`).join('') + (cfg.actions ? '<th></th>' : '');

    const body = pageRows.length ? pageRows.map(r => {
      const tds = cfg.columns.map(c => {
        const raw = c.render ? c.render(r) : U.esc(r[c.key]);
        return `<td class="${c.num ? 'num' : ''}">${raw}</td>`;
      }).join('');
      return `<tr data-id="${r.id}">${tds}${cfg.actions ? `<td>${cfg.actions(r)}</td>` : ''}</tr>`;
    }).join('') : `<tr><td colspan="${cfg.columns.length + 1}"><div class="empty-state">No records yet — add one above.</div></td></tr>`;

    container.innerHTML = `
      <div class="table-wrap glass"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
      <div class="pagination">
        <span>${rows.length} record${rows.length === 1 ? '' : 's'}</span>
        <button class="btn ghost small" data-pg="prev" ${state.page <= 1 ? 'disabled' : ''}>‹</button>
        <span>Page ${state.page} / ${pages}</span>
        <button class="btn ghost small" data-pg="next" ${state.page >= pages ? 'disabled' : ''}>›</button>
      </div>`;

    container.querySelectorAll('thead th[data-key]').forEach(th => {
      th.onclick = () => {
        const k = th.dataset.key;
        if (state.sortKey === k) state.sortDir *= -1;
        else { state.sortKey = k; state.sortDir = -1; }
        U.renderTable(container, cfg);
      };
    });
    container.querySelector('[data-pg="prev"]').onclick = () => { state.page--; U.renderTable(container, cfg); };
    container.querySelector('[data-pg="next"]').onclick = () => { state.page++; U.renderTable(container, cfg); };
    if (cfg.onRowClick) container.querySelectorAll('tbody tr[data-id]').forEach(tr =>
      tr.addEventListener('click', e => {
        if (e.target.closest('.icon-btn')) return;
        cfg.onRowClick(tr.dataset.id, tr);
      }));
    if (cfg.bindActions) cfg.bindActions(container);
  },

  download(filename, content, mime = 'text/plain') {
    const blob = content instanceof Blob ? content : new Blob([content], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },
};

/* ---------- Undo / Redo (snapshot of data collections) ---------- */
const History = {
  undoStack: [], redoStack: [], max: 40,

  snapshot(label) {
    this.undoStack.push({ label, data: Store.exportData() });
    if (this.undoStack.length > this.max) this.undoStack.shift();
    this.redoStack.length = 0;
  },
  undo() {
    if (!this.undoStack.length) return U.toast('Nothing to undo');
    this.redoStack.push({ label: 'redo', data: Store.exportData() });
    const snap = this.undoStack.pop();
    Store.importData(snap.data, true);
    App.refreshAll();
    U.toast('Undid: ' + snap.label);
  },
  redo() {
    if (!this.redoStack.length) return U.toast('Nothing to redo');
    this.undoStack.push({ label: 'undo', data: Store.exportData() });
    const snap = this.redoStack.pop();
    Store.importData(snap.data, true);
    App.refreshAll();
    U.toast('Redone');
  },
};
