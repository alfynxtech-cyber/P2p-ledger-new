/* ============================================================
   expenses.js — Expenses page (CRUD + filter + export)
   ============================================================ */
'use strict';

const Expenses = {
  editingId: null,
  filters: { from: '', to: '', category: '', text: '' },

  render() {
    const root = document.getElementById('page-expenses');
    const cats = Store.lists().expenseCategories;

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Expenses<small>Operating costs deducted from gross profit</small></h2>
        <button class="btn ghost" id="expExport">⇩ Export CSV</button>
      </div>

      <div class="panel">
        <h3>${this.editingId ? 'Edit expense' : 'New expense'}</h3>
        <div class="form-grid">
          <div class="field"><label>Date</label><input type="date" id="expDate" value="${U.todayISO()}"></div>
          <div class="field"><label>Expense Name</label><input id="expName" placeholder="e.g. Broadband bill"></div>
          <div class="field"><label>Category</label><select id="expCat">${U.optionList(cats)}</select></div>
          <div class="field"><label>Amount (${U.esc(Store.settings().currencySymbol)})</label><input type="number" step="any" min="0" id="expAmount"></div>
          <div class="field span-2"><label>Description</label><input id="expDesc" placeholder="Optional details"></div>
        </div>
        <div class="btn-row">
          <button class="btn" id="expSave">${this.editingId ? 'Update' : 'Save'}</button>
          <button class="btn ghost" id="expClear">Clear</button>
        </div>
      </div>

      <div class="filter-bar">
        <div class="field"><label>From</label><input type="date" id="expFFrom" value="${this.filters.from}"></div>
        <div class="field"><label>To</label><input type="date" id="expFTo" value="${this.filters.to}"></div>
        <div class="field"><label>Category</label><select id="expFCat"><option value="">All</option>${U.optionList(cats, this.filters.category)}</select></div>
        <div class="field" style="flex:1"><label>Search</label><input id="expFText" value="${U.esc(this.filters.text)}" placeholder="name / description / amount"></div>
      </div>

      <div id="expTable"></div>`;

    this.bind();
    this.renderTable();
  },

  bind() {
    const $ = id => document.getElementById(id);
    $('expSave').onclick = () => this.save();
    $('expClear').onclick = () => { this.editingId = null; this.render(); };
    $('expExport').onclick = () => Excel.exportExpensesCSV(this.filtered());

    const apply = U.debounce(() => {
      this.filters = { from: $('expFFrom').value, to: $('expFTo').value, category: $('expFCat').value, text: $('expFText').value };
      this.renderTable();
    }, 200);
    ['expFFrom', 'expFTo', 'expFCat'].forEach(f => $(f).addEventListener('change', apply));
    $('expFText').addEventListener('input', apply);
  },

  save() {
    const $ = id => document.getElementById(id);
    const e = {
      date: $('expDate').value, name: $('expName').value.trim(),
      category: $('expCat').value, amount: U.num($('expAmount').value),
      description: $('expDesc').value.trim(),
    };
    let ok = true;
    const mark = (id, bad) => { $(id).classList.toggle('invalid', bad); if (bad) ok = false; };
    mark('expDate', !e.date); mark('expName', !e.name); mark('expAmount', e.amount <= 0);
    if (!ok) return U.toast('Fix the highlighted fields', true);

    History.snapshot(this.editingId ? 'Update expense' : 'Add expense');
    if (this.editingId) {
      const i = Store.expenses().findIndex(x => x.id === this.editingId);
      Store.expenses()[i] = { ...Store.expenses()[i], ...e };
      U.toast('Expense updated');
    } else {
      Store.expenses().unshift({ id: U.uid(), ...e });
      U.toast('Expense saved');
    }
    Store.log('expense:save', `${e.name} ${U.fmtMoney(e.amount)}`);
    Store.save();
    this.editingId = null;
    this.render();
    Dashboard.refresh();
  },

  edit(id) {
    const e = Store.expenses().find(x => x.id === id);
    if (!e) return;
    this.editingId = id;
    this.render();
    const $ = f => document.getElementById(f);
    $('expDate').value = e.date; $('expName').value = e.name;
    $('expCat').value = e.category; $('expAmount').value = e.amount;
    $('expDesc').value = e.description || '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  async del(id) {
    const e = Store.expenses().find(x => x.id === id);
    if (!await U.confirm(`Delete expense "${e?.name}" (${U.fmtMoney(e?.amount || 0)})?`)) return;
    History.snapshot('Delete expense');
    Store.expenses().splice(Store.expenses().findIndex(x => x.id === id), 1);
    Store.log('expense:delete', e.name);
    Store.save();
    if (this.editingId === id) this.editingId = null;
    this.render();
    Dashboard.refresh();
    U.toast('Deleted');
  },

  filtered() {
    const f = this.filters, txt = f.text.toLowerCase();
    return Store.expenses().filter(e =>
      U.inRange(e.date, f.from, f.to) &&
      (!f.category || e.category === f.category) &&
      (!txt || [e.name, e.description, String(e.amount)].join(' ').toLowerCase().includes(txt)));
  },

  renderTable() {
    const c = document.getElementById('expTable');
    if (!c) return;
    U.renderTable(c, {
      defaultSort: 'date',
      rows: this.filtered(),
      columns: [
        { key: 'date', label: 'Date', render: r => U.fmtDate(r.date) },
        { key: 'name', label: 'Expense' },
        { key: 'category', label: 'Category', render: r => `<span class="tag">${U.esc(r.category)}</span>` },
        { key: 'amount', label: 'Amount', num: true, render: r => `<span class="neg">${U.fmtMoney(r.amount)}</span>` },
        { key: 'description', label: 'Description' },
      ],
      actions: r => `
        <button class="icon-btn" data-act="edit" data-id="${r.id}">✎</button>
        <button class="icon-btn" data-act="del" data-id="${r.id}">🗑</button>`,
      bindActions: cc => cc.querySelectorAll('.icon-btn').forEach(b => {
        b.onclick = () => b.dataset.act === 'edit' ? this.edit(b.dataset.id) : this.del(b.dataset.id);
      }),
      onRowClick: id => this.edit(id),
    });
  },
};
