/* ============================================================
   sell.js — Sell Transactions page.
   Uses TradePageFactory from buy.js; the only differences
   (buyer label, total = price × net quantity) are handled there.
   ============================================================ */
'use strict';

const Sell = TradePageFactory('sell');
