/* ============================================================
   buy.js — Buy Transactions page.
   Also defines TradePageFactory, reused by sell.js so the two
   nearly-identical pages share one implementation.
   ============================================================ */
'use strict';

/**
 * Factory that builds a full trade page (form + filters + table).
 * kind: 'buy' | 'sell'
 */
function TradePageFactory(kind) {
  const isBuy = kind === 'buy';
  const partyLabel = isBuy ? 'Seller Name' : 'Buyer Name';
  const totalLabel = isBuy ? 'Total Amount Paid' : 'Total Amount Received';
  const list = () => (isBuy ? Store.buys() : Store.sells());

  const page = {
    editingId: null,
    filters: { from: '', to: '', asset: '', bank: '', mode: '', text: '' },

    /* ---------- computations ---------- */
    compute(qty, fees, price) {
      // Formulas are editable in Admin → Calculation Formulas
      // (defaults: Net = Qty − Fees · Buy = Price × Qty · Sell = Price × Net Qty)
      return Formulas.tradeCalc(kind, qty, fees, price);
    },

    /* ---------- render ---------- */
    render() {
      const root = document.getElementById('page-' + kind);
      const L = Store.lists();
      const S = Store.settings();
      const pinned = S.pinnedFilters[kind];
      if (pinned) this.filters = { ...this.filters, ...pinned };

      root.innerHTML = `
        <div class="page-head">
          <h2 class="page-title">${isBuy ? 'Buy' : 'Sell'} Transactions
            <small>${isBuy ? 'Record every purchase — totals & net quantity auto-calculate' : 'Record every sale — totals auto-calculate on net quantity'}</small></h2>
        </div>

        <div class="panel">
          <h3>${this.editingId ? 'Edit transaction' : 'New transaction'}</h3>
          <div class="form-grid" id="${kind}FormGrid">
            <div class="field"><label>Transaction Date</label><input type="date" id="${kind}Date" value="${U.todayISO()}"></div>
            <div class="field"><label>${partyLabel}</label><input id="${kind}Party" placeholder="e.g. Rahul Traders" list="${kind}PartyList">
              <datalist id="${kind}PartyList">${[...new Set(list().map(t => t.party).filter(Boolean))].map(p => `<option value="${U.esc(p)}">`).join('')}</datalist></div>
            <div class="field"><label>Asset</label>
              <select id="${kind}Asset">${U.optionList(L.assets, S.defaultAsset)}<option value="__custom__">Custom…</option></select></div>
            <div class="field"><label>Quantity ($)</label><input type="number" step="any" min="0" id="${kind}Qty" placeholder="0.00"></div>
            <div class="field"><label>Fees</label><input type="number" step="any" min="0" id="${kind}Fees" value="0"></div>
            <div class="field"><label>Price (${U.esc(S.currencySymbol)})</label><input type="number" step="any" min="0" id="${kind}Price" placeholder="0.00"></div>
            <div class="field"><label>Net Quantity${isBuy ? '' : ' Sold'}</label><input readonly id="${kind}NetQty" value="0.00"><span class="hint">Quantity − Fees</span></div>
            <div class="field"><label>${totalLabel}</label><input readonly id="${kind}Total" value="0.00"><span class="hint">${isBuy ? 'Price × Quantity' : 'Price × Net Quantity Sold'}</span></div>
            <div class="field"><label>Bank Name</label><select id="${kind}Bank">${U.optionList(L.banks, S.defaultBank)}</select></div>
            <div class="field"><label>Payment Mode</label><select id="${kind}Mode">${U.optionList(L.modes, S.defaultMode)}</select></div>
            <div class="field"><label>UTR Number</label><input id="${kind}Utr" placeholder="12-digit UTR"></div>
            <div class="field"><label>Binance Order Number</label><input id="${kind}OrderNo" inputmode="numeric" placeholder="e.g. 22456789012345678901"></div>
            <div class="field"><label>Tags</label><input id="${kind}Tags" placeholder="comma,separated"></div>
            <div class="field span-2"><label>Notes</label><input id="${kind}Notes" placeholder="Optional notes"></div>
          </div>
          <div class="btn-row">
            <button class="btn" id="${kind}Save">${this.editingId ? 'Update' : 'Save'}</button>
            ${this.editingId ? `<button class="btn danger" id="${kind}DeleteEditing">Delete</button>` : ''}
            <button class="btn ghost" id="${kind}Clear">Clear</button>
            <button class="btn ghost" id="${kind}Duplicate" ${this.editingId ? '' : 'disabled'}>Duplicate</button>
          </div>
        </div>

        <div class="filter-bar">
          <div class="field"><label>From</label><input type="date" id="${kind}FFrom" value="${this.filters.from}"></div>
          <div class="field"><label>To</label><input type="date" id="${kind}FTo" value="${this.filters.to}"></div>
          <div class="field"><label>Asset</label><select id="${kind}FAsset"><option value="">All</option>${U.optionList(L.assets, this.filters.asset)}</select></div>
          <div class="field"><label>Bank</label><select id="${kind}FBank"><option value="">All</option>${U.optionList(L.banks, this.filters.bank)}</select></div>
          <div class="field"><label>Mode</label><select id="${kind}FMode"><option value="">All</option>${U.optionList(L.modes, this.filters.mode)}</select></div>
          <div class="field" style="flex:1"><label>Search</label><input id="${kind}FText" placeholder="party / UTR / order no / notes / tag / amount" value="${U.esc(this.filters.text)}"></div>
          <button class="btn ghost small pin-filter" id="${kind}PinFilter" title="Pin these filters">📌 Pin</button>
          <button class="btn ghost small pin-filter" id="${kind}ResetFilter">Reset</button>
        </div>

        <div id="${kind}Table"></div>`;

      this.bind();
      this.recalc();
      this.renderTable();
    },

    /* ---------- events ---------- */
    bind() {
      const $ = id => document.getElementById(kind + id);

      ['Qty', 'Fees', 'Price'].forEach(f => $(f).addEventListener('input', () => this.recalc()));

      $('Asset').addEventListener('change', e => {
        if (e.target.value === '__custom__') {
          const name = prompt('New asset symbol (e.g. SOL):');
          if (name && name.trim()) {
            const sym = name.trim().toUpperCase();
            if (!Store.lists().assets.includes(sym)) { Store.lists().assets.push(sym); Store.save(); }
            this.render();
            document.getElementById(kind + 'Asset').value = sym;
          } else e.target.value = Store.settings().defaultAsset;
        }
      });

      $('Save').onclick = () => this.saveTx();
      $('Clear').onclick = () => { this.editingId = null; this.render(); };
      $('Duplicate').onclick = () => this.duplicate();
      const del = document.getElementById(kind + 'DeleteEditing');
      if (del) del.onclick = () => this.deleteTx(this.editingId);

      // filters
      const applyF = U.debounce(() => {
        this.filters = {
          from: $('FFrom').value, to: $('FTo').value,
          asset: $('FAsset').value, bank: $('FBank').value,
          mode: $('FMode').value, text: $('FText').value,
        };
        this.renderTable();
      }, 200);
      ['FFrom', 'FTo', 'FAsset', 'FBank', 'FMode'].forEach(f => $(f).addEventListener('change', applyF));
      $('FText').addEventListener('input', applyF);
      $('PinFilter').onclick = () => {
        Store.settings().pinnedFilters[kind] = { ...this.filters };
        Store.save(); U.toast('Filters pinned — they will reload next visit');
      };
      $('ResetFilter').onclick = () => {
        delete Store.settings().pinnedFilters[kind]; Store.save();
        this.filters = { from: '', to: '', asset: '', bank: '', mode: '', text: '' };
        this.render();
      };
    },

    recalc() {
      const $ = id => document.getElementById(kind + id);
      if (!$('Qty')) return;
      const { netQty, total } = this.compute($('Qty').value, $('Fees').value, $('Price').value);
      $('NetQty').value = U.fmtNum(netQty, 4);
      $('Total').value = U.fmtNum(total);
    },

    readForm() {
      const $ = id => document.getElementById(kind + id);
      const qty = U.num($('Qty').value), fees = U.num($('Fees').value), price = U.num($('Price').value);
      const { netQty, total } = this.compute(qty, fees, price);
      return {
        date: $('Date').value, party: $('Party').value.trim(),
        asset: $('Asset').value, qty, fees, price, netQty, total,
        bank: $('Bank').value, mode: $('Mode').value,
        utr: $('Utr').value.trim(), orderNo: $('OrderNo').value.trim(), notes: $('Notes').value.trim(),
        tags: $('Tags').value.split(',').map(t => t.trim()).filter(Boolean),
      };
    },

    validate(tx) {
      const $ = id => document.getElementById(kind + id);
      let ok = true;
      const mark = (id, bad) => { $(id).classList.toggle('invalid', bad); if (bad) ok = false; };
      mark('Date', !tx.date);
      mark('Party', !tx.party);
      mark('Qty', tx.qty <= 0);
      mark('Price', tx.price <= 0);
      mark('Fees', tx.fees < 0 || tx.fees > tx.qty);
      return ok;
    },

    async saveTx() {
      const tx = this.readForm();
      if (!this.validate(tx)) return U.toast('Fix the highlighted fields', true);

      if (Store.isDuplicate(kind, tx, this.editingId)) {
        const go = await U.confirm('Possible duplicate detected (same UTR, same Binance order number, or same date + amount + party). Save anyway?', 'Save anyway');
        if (!go) return;
      }

      History.snapshot((this.editingId ? 'Update ' : 'Add ') + kind);
      if (this.editingId) {
        const i = list().findIndex(t => t.id === this.editingId);
        list()[i] = { ...list()[i], ...tx };
        Store.log(kind + ':update', `${tx.party} ${U.fmtMoney(tx.total)}`);
        U.toast('Transaction updated');
      } else {
        list().unshift({ id: U.uid(), createdAt: new Date().toISOString(), fav: false, ...tx });
        Store.log(kind + ':add', `${tx.party} ${U.fmtMoney(tx.total)}`);
        U.toast('Transaction saved');
      }
      Store.save();
      this.editingId = null;
      this.render();
      Dashboard.refresh();
    },

    edit(id) {
      const t = list().find(x => x.id === id);
      if (!t) return;
      this.editingId = id;
      this.render();
      const $ = f => document.getElementById(kind + f);
      $('Date').value = t.date; $('Party').value = t.party;
      $('Asset').value = t.asset; $('Qty').value = t.qty;
      $('Fees').value = t.fees; $('Price').value = t.price;
      $('Bank').value = t.bank; $('Mode').value = t.mode;
      $('Utr').value = t.utr || ''; $('OrderNo').value = t.orderNo || ''; $('Notes').value = t.notes || '';
      $('Tags').value = (t.tags || []).join(', ');
      this.recalc();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },

    duplicate() {
      const t = list().find(x => x.id === this.editingId);
      if (!t) return;
      History.snapshot('Duplicate ' + kind);
      list().unshift({ ...t, id: U.uid(), utr: '', orderNo: '', createdAt: new Date().toISOString() });
      Store.log(kind + ':duplicate', t.party);
      Store.save();
      this.editingId = null;
      this.render();
      U.toast('Duplicated — remember to set the new UTR & order number');
    },

    async deleteTx(id) {
      const t = list().find(x => x.id === id);
      const go = await U.confirm(`Delete this ${kind} of ${U.fmtMoney(t?.total || 0)} (${U.esc(t?.party || '')})? This cannot be recovered without Undo.`);
      if (!go) return;
      History.snapshot('Delete ' + kind);
      const i = list().findIndex(x => x.id === id);
      list().splice(i, 1);
      Store.log(kind + ':delete', t.party);
      Store.save();
      if (this.editingId === id) this.editingId = null;
      this.render();
      Dashboard.refresh();
      U.toast('Deleted');
    },

    toggleFav(id) {
      const t = list().find(x => x.id === id);
      t.fav = !t.fav;
      Store.save();
      this.renderTable();
    },

    filtered() {
      const f = this.filters;
      const txt = f.text.toLowerCase();
      return list().filter(t =>
        U.inRange(t.date, f.from, f.to) &&
        (!f.asset || t.asset === f.asset) &&
        (!f.bank || t.bank === f.bank) &&
        (!f.mode || t.mode === f.mode) &&
        (!txt ||
          [t.party, t.utr, t.orderNo, t.notes, t.bank, t.mode, String(t.total), String(t.price), ...(t.tags || [])]
            .join(' ').toLowerCase().includes(txt))
      );
    },

    renderTable() {
      const container = document.getElementById(kind + 'Table');
      if (!container) return;
      U.renderTable(container, {
        defaultSort: 'date',
        rows: this.filtered(),
        columns: [
          { key: 'date', label: 'Date', render: r => U.fmtDate(r.date) },
          { key: 'party', label: partyLabel.replace(' Name', ''), render: r => `${r.fav ? '★ ' : ''}${U.esc(r.party)}${(r.tags || []).map(t => ` <span class="tag">${U.esc(t)}</span>`).join('')}` },
          { key: 'asset', label: 'Asset' },
          { key: 'qty', label: 'Qty ($)', num: true, render: r => U.fmtNum(r.qty, 4) },
          { key: 'fees', label: 'Fees', num: true, render: r => U.fmtNum(r.fees, 4) },
          { key: 'netQty', label: 'Net Qty', num: true, render: r => U.fmtNum(r.netQty, 4) },
          { key: 'price', label: 'Price', num: true, render: r => U.fmtMoney(r.price) },
          { key: 'total', label: totalLabel.replace('Total Amount ', ''), num: true, render: r => `<span class="${isBuy ? '' : 'pos'}">${U.fmtMoney(r.total)}</span>` },
          { key: 'bank', label: 'Bank' },
          { key: 'mode', label: 'Mode' },
          { key: 'utr', label: 'UTR' },
          { key: 'orderNo', label: 'Binance Order No.' },
        ],
        actions: r => `
          <button class="icon-btn fav ${r.fav ? 'on' : ''}" data-act="fav" data-id="${r.id}" title="Favourite">★</button>
          <button class="icon-btn" data-act="edit" data-id="${r.id}" title="Edit">✎</button>
          <button class="icon-btn" data-act="del" data-id="${r.id}" title="Delete">🗑</button>`,
        bindActions: c => c.querySelectorAll('.icon-btn').forEach(b => {
          b.onclick = () => {
            const { act, id } = b.dataset;
            if (act === 'edit') this.edit(id);
            else if (act === 'del') this.deleteTx(id);
            else if (act === 'fav') this.toggleFav(id);
          };
        }),
        onRowClick: id => this.edit(id),
      });
    },
  };

  return page;
}

const Buy = TradePageFactory('buy');
