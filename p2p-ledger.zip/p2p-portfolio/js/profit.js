/* ============================================================
   profit.js — aggregation engine (Calc) + Profit Report page.
   Calc is also used by Dashboard, Summary and Tax modules.
   ============================================================ */
'use strict';

/* ---------- Calc: pure aggregation over a filtered scope ---------- */
const Calc = {

  scope({ from = '', to = '', asset = '' } = {}) {
    const inScope = t => U.inRange(t.date, from, to) && (!asset || t.asset === asset);
    return {
      buys: Store.buys().filter(inScope),
      sells: Store.sells().filter(inScope),
      expenses: Store.expenses().filter(e => U.inRange(e.date, from, to)),
    };
  },

  totals(scope) {
    const sum = (arr, f) => arr.reduce((s, x) => s + U.num(f(x)), 0);
    const buy = sum(scope.buys, t => t.total);
    const sell = sum(scope.sells, t => t.total);
    const buyQty = sum(scope.buys, t => t.netQty);
    const sellQty = sum(scope.sells, t => t.netQty);
    // fee value in currency — formula editable in Admin
    const feeVal = t => Formulas.run('feeValue', { qty: t.qty, fees: t.fees, price: t.price, netQty: t.netQty });
    const buyFeesValue = sum(scope.buys, feeVal);
    const sellFeesValue = sum(scope.sells, feeVal);
    const expenses = sum(scope.expenses, e => e.amount);
    const F = (id, v) => Formulas.run(id, v);
    const holdings = F('holdings', { buyQty, sellQty });
    const gross = U.round2(F('grossProfit', { sell, buy, buyFees: buyFeesValue, sellFees: sellFeesValue, expenses, buyQty, sellQty }));
    const net = U.round2(F('netProfit', { gross, sell, buy, buyFees: buyFeesValue, sellFees: sellFeesValue, expenses }));
    return {
      buy: U.round2(buy), sell: U.round2(sell),
      buyQty: U.round2(buyQty), sellQty: U.round2(sellQty),
      holdings: U.round2(holdings),
      avgBuy: U.round2(F('avgBuy', { buy, buyQty })),
      avgSell: U.round2(F('avgSell', { sell, sellQty })),
      buyFeesValue: U.round2(buyFeesValue), sellFeesValue: U.round2(sellFeesValue),
      expenses: U.round2(expenses),
      gross, net,
      roi: U.round2(F('roi', { net, gross, sell, buy, expenses })),
      trades: scope.buys.length + scope.sells.length,
    };
  },

  /* Group by a key function -> map of key -> totals */
  groupBy(scope, keyFn, expenseKeyFn) {
    const groups = {};
    const bucket = k => groups[k] ||= { buys: [], sells: [], expenses: [] };
    scope.buys.forEach(t => bucket(keyFn(t)).buys.push(t));
    scope.sells.forEach(t => bucket(keyFn(t)).sells.push(t));
    scope.expenses.forEach(e => bucket((expenseKeyFn || keyFn)(e)).expenses.push(e));
    const out = {};
    Object.keys(groups).sort().forEach(k => out[k] = this.totals(groups[k]));
    return out;
  },

  byDay(scope) { return this.groupBy(scope, t => t.date); },
  byWeek(scope) { return this.groupBy(scope, t => U.weekKey(t.date)); },
  byMonth(scope) { return this.groupBy(scope, t => U.monthKey(t.date)); },
  byQuarter(scope) { return this.groupBy(scope, t => U.quarterKey(t.date)); },
  byYear(scope) { return this.groupBy(scope, t => U.yearKey(t.date)); },
  byAsset(scope) {
    // expenses aren't asset-specific; keep them out of per-asset groups
    const s = { ...scope, expenses: [] };
    return this.groupBy(s, t => t.asset, () => '—');
  },
  byBank(scope) { const s = { ...scope, expenses: [] }; return this.groupBy(s, t => t.bank || '—'); },
  byMode(scope) { const s = { ...scope, expenses: [] }; return this.groupBy(s, t => t.mode || '—'); },
};

/* ---------- Profit Report page ---------- */
const Profit = {
  filters: { from: '', to: '', asset: '', group: 'month' },

  render() {
    const root = document.getElementById('page-profit');
    if (Store.admin().disabledReports.includes('profit')) {
      root.innerHTML = '<div class="panel"><h3>Profit Report is disabled</h3><p>An admin has turned this report off. Enable it again from the Admin Panel.</p></div>';
      return;
    }
    const L = Store.lists();
    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Profit Report<small>Gross Profit = configured formula · Net Profit = Gross − Expenses</small></h2>
      </div>

      <div class="filter-bar">
        <div class="field"><label>From</label><input type="date" id="pfFrom" value="${this.filters.from}"></div>
        <div class="field"><label>To</label><input type="date" id="pfTo" value="${this.filters.to}"></div>
        <div class="field"><label>Asset</label><select id="pfAsset"><option value="">All</option>${U.optionList(L.assets, this.filters.asset)}</select></div>
        <div class="field"><label>Group by</label>
          <select id="pfGroup">
            <option value="day">Daily</option><option value="week">Weekly</option>
            <option value="month" selected>Monthly</option><option value="year">Yearly</option>
            <option value="asset">By Asset</option>
          </select></div>
      </div>

      <div class="cards-grid" id="pfCards"></div>
      <div id="pfTable"></div>`;

    const $ = id => document.getElementById(id);
    $('pfGroup').value = this.filters.group;
    const apply = () => {
      this.filters = { from: $('pfFrom').value, to: $('pfTo').value, asset: $('pfAsset').value, group: $('pfGroup').value };
      this.draw();
    };
    ['pfFrom', 'pfTo', 'pfAsset', 'pfGroup'].forEach(f => $(f).addEventListener('change', apply));
    this.draw();
  },

  draw() {
    const scope = Calc.scope(this.filters);
    const T = Calc.totals(scope);

    document.getElementById('pfCards').innerHTML = [
      ['Total Sell', U.fmtMoney(T.sell), ''],
      ['Total Buy', U.fmtMoney(T.buy), ''],
      ['Gross Profit', U.fmtMoney(T.gross), T.gross >= 0 ? 'pos' : 'neg'],
      ['Expenses', U.fmtMoney(T.expenses), 'neg'],
      ['Net Profit', U.fmtMoney(T.net), T.net >= 0 ? 'pos' : 'neg'],
      ['ROI', U.fmtNum(T.roi) + '%', T.roi >= 0 ? 'pos' : 'neg'],
    ].map(([l, v, cls]) => `
      <div class="stat-card card"><div class="stat-label">${l}</div><div class="stat-value ${cls}">${v}</div></div>`).join('');

    const groupFns = { day: 'byDay', week: 'byWeek', month: 'byMonth', year: 'byYear', asset: 'byAsset' };
    const groups = Calc[groupFns[this.filters.group]](scope);
    const rows = Object.entries(groups).map(([k, t]) => ({ id: k, period: k, ...t }));

    U.renderTable(document.getElementById('pfTable'), {
      defaultSort: 'period',
      rows,
      pageSize: 20,
      columns: [
        { key: 'period', label: this.filters.group === 'asset' ? 'Asset' : 'Period' },
        { key: 'buy', label: 'Total Buy', num: true, render: r => U.fmtMoney(r.buy) },
        { key: 'sell', label: 'Total Sell', num: true, render: r => U.fmtMoney(r.sell) },
        { key: 'gross', label: 'Gross Profit', num: true, render: r => `<span class="${r.gross >= 0 ? 'pos' : 'neg'}">${U.fmtMoney(r.gross)}</span>` },
        { key: 'expenses', label: 'Expenses', num: true, render: r => U.fmtMoney(r.expenses) },
        { key: 'net', label: 'Net Profit', num: true, render: r => `<span class="${r.net >= 0 ? 'pos' : 'neg'}">${U.fmtMoney(r.net)}</span>` },
        { key: 'trades', label: 'Trades', num: true },
      ],
    });
  },
};
