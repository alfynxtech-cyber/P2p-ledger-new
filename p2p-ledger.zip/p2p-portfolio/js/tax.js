/* ============================================================
   tax.js — Tax Reports page (CA-ready), with exports & print
   ============================================================ */
'use strict';

const Tax = {
  mode: 'fy', // fy | cy | range
  lastReport: null,

  render() {
    const root = document.getElementById('page-tax');
    if (Store.admin().disabledReports.includes('tax')) {
      root.innerHTML = '<div class="panel"><h3>Tax Report is disabled</h3><p>Enable it from the Admin Panel.</p></div>';
      return;
    }
    const fys = [...new Set([...Store.buys(), ...Store.sells(), ...Store.expenses()].map(t => U.fyKey(t.date)))].sort().reverse();
    const years = [...new Set([...Store.buys(), ...Store.sells()].map(t => U.yearKey(t.date)))].sort().reverse();

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Tax Report<small>Formatted for hand-off to your Chartered Accountant</small></h2>
        <div class="btn-row" style="margin:0">
          <button class="btn ghost small" id="taxXlsx">Excel</button>
          <button class="btn ghost small" id="taxCsv">CSV</button>
          <button class="btn ghost small" id="taxPdf">PDF</button>
          <button class="btn ghost small" id="taxPrint">🖨 Print</button>
        </div>
      </div>

      <div class="filter-bar">
        <div class="field"><label>Period type</label>
          <select id="taxMode">
            <option value="fy">Financial Year (Apr–Mar)</option>
            <option value="cy">Calendar Year</option>
            <option value="range">Custom Range</option>
          </select></div>
        <div class="field" id="taxWrapFy"><label>FY</label><select id="taxFy">${fys.map(f => `<option>${f}</option>`).join('') || '<option value="">No data</option>'}</select></div>
        <div class="field" id="taxWrapCy" hidden><label>Year</label><select id="taxCy">${years.map(y => `<option>${y}</option>`).join('') || '<option value="">No data</option>'}</select></div>
        <div class="field" id="taxWrapFrom" hidden><label>From</label><input type="date" id="taxFrom"></div>
        <div class="field" id="taxWrapTo" hidden><label>To</label><input type="date" id="taxTo"></div>
      </div>

      <div id="taxReport"></div>`;

    const $ = id => document.getElementById(id);
    $('taxMode').value = this.mode;
    const sync = () => {
      this.mode = $('taxMode').value;
      $('taxWrapFy').hidden = this.mode !== 'fy';
      $('taxWrapCy').hidden = this.mode !== 'cy';
      $('taxWrapFrom').hidden = $('taxWrapTo').hidden = this.mode !== 'range';
      this.draw();
    };
    ['taxMode', 'taxFy', 'taxCy', 'taxFrom', 'taxTo'].forEach(f => $(f).addEventListener('change', sync));
    $('taxXlsx').onclick = () => Excel.exportTax(this.lastReport, 'xlsx');
    $('taxCsv').onclick = () => Excel.exportTax(this.lastReport, 'csv');
    $('taxPdf').onclick = () => window.print(); // print-to-PDF via browser dialog
    $('taxPrint').onclick = () => window.print();
    sync();
  },

  currentRange() {
    const $ = id => document.getElementById(id);
    if (this.mode === 'fy') { const v = $('taxFy').value; return v ? U.fyRange(v) : ['', '']; }
    if (this.mode === 'cy') { const y = $('taxCy').value; return y ? [y + '-01-01', y + '-12-31'] : ['', '']; }
    return [$('taxFrom').value, $('taxTo').value];
  },

  currentLabel() {
    const $ = id => document.getElementById(id);
    if (this.mode === 'fy') return 'FY ' + $('taxFy').value;
    if (this.mode === 'cy') return 'Calendar Year ' + $('taxCy').value;
    return `${U.fmtDate($('taxFrom').value) || '…'} to ${U.fmtDate($('taxTo').value) || '…'}`;
  },

  draw() {
    const [from, to] = this.currentRange();
    const scope = Calc.scope({ from, to });
    const T = Calc.totals(scope);
    const byBank = Calc.byBank(scope);
    const byAsset = Calc.byAsset(scope);
    const byMode = Calc.byMode(scope);
    const byMonth = Calc.byMonth(scope);
    const byQuarter = Calc.byQuarter(scope);
    const byYear = Calc.byYear(scope);

    this.lastReport = { label: this.currentLabel(), from, to, totals: T, byBank, byAsset, byMode, byMonth, byQuarter, byYear };

    const miniTable = (title, obj, keyLabel, cols) => `
      <div class="panel">
        <h3>${title}</h3>
        <div class="table-wrap"><table>
          <thead><tr><th>${keyLabel}</th>${cols.map(c => `<th class="num">${c[0]}</th>`).join('')}</tr></thead>
          <tbody>${Object.entries(obj).filter(([k]) => k !== '—').map(([k, t]) => `
            <tr><td>${U.esc(k)}</td>${cols.map(c => `<td class="num">${c[1](t)}</td>`).join('')}</tr>`).join('') ||
            '<tr><td colspan="9"><div class="empty-state">No data in this period</div></td></tr>'}
          </tbody></table></div>
      </div>`;

    const money = f => t => U.fmtMoney(t[f]);
    const profitCols = [['Buy', money('buy')], ['Sell', money('sell')], ['Gross Profit', money('gross')], ['Net Profit', money('net')], ['Trades', t => t.trades]];

    document.getElementById('taxReport').innerHTML = `
      <div class="panel">
        <h3>Overview — ${U.esc(this.lastReport.label)}</h3>
        <div class="cards-grid">
          ${[['Total Buy', T.buy], ['Total Sell', T.sell], ['Total Expenses', T.expenses], ['Gross Profit', T.gross], ['Net Profit', T.net]]
            .map(([l, v]) => `<div class="stat-card card"><div class="stat-label">${l}</div>
              <div class="stat-value ${l.includes('Profit') ? (v >= 0 ? 'pos' : 'neg') : ''}">${U.fmtMoney(v)}</div></div>`).join('')}
        </div>
      </div>
      ${miniTable('Bank-wise Totals', byBank, 'Bank', [['Buy', money('buy')], ['Sell', money('sell')], ['Gross', money('gross')]])}
      ${miniTable('Asset-wise Totals', byAsset, 'Asset', [['Buy', money('buy')], ['Sell', money('sell')], ['Gross', money('gross')], ['Holding', t => U.fmtNum(t.holdings, 4)]])}
      ${miniTable('Payment Mode Totals', byMode, 'Mode', [['Buy', money('buy')], ['Sell', money('sell')], ['Trades', t => t.trades]])}
      ${miniTable('Monthly Profit', byMonth, 'Month', profitCols)}
      ${miniTable('Quarterly Profit', byQuarter, 'Quarter', profitCols)}
      ${miniTable('Yearly Profit', byYear, 'Year', profitCols)}`;
  },
};
