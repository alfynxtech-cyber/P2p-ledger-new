/* ============================================================
   excel.js — Import/Export page.
   Import: xlsx/csv with auto column mapping, preview, merge,
   duplicate-UTR / duplicate-transaction skipping.
   Export: Excel, CSV, JSON, backup/restore. PDF via print.
   ============================================================ */
'use strict';

const Excel = {
  pending: null, // { kind, headers, rows, mapping }

  FIELDS: {
    buy: ['date', 'party', 'asset', 'qty', 'fees', 'price', 'bank', 'mode', 'utr', 'orderNo', 'notes'],
    sell: ['date', 'party', 'asset', 'qty', 'fees', 'price', 'bank', 'mode', 'utr', 'orderNo', 'notes'],
    expenses: ['date', 'name', 'category', 'amount', 'description'],
  },

  // Header aliases for auto-mapping
  ALIASES: {
    date: ['date', 'transaction date', 'txn date'],
    party: ['seller', 'buyer', 'seller name', 'buyer name', 'party', 'name', 'counterparty'],
    asset: ['asset', 'coin', 'currency', 'token'],
    qty: ['qty', 'quantity', 'quantity ($)', 'amount ($)', 'usdt'],
    fees: ['fees', 'fee', 'charges'],
    price: ['price', 'rate', 'price (₹)', 'price inr'],
    bank: ['bank', 'bank name'],
    mode: ['mode', 'payment mode', 'payment method', 'method'],
    utr: ['utr', 'utr number', 'reference', 'ref no', 'txn id'],
    orderNo: ['binance order number', 'binance order no', 'binance order no.', 'order number', 'order no', 'order no.', 'order id', 'orderno', 'order'],
    notes: ['notes', 'note', 'remark', 'remarks'],
    name: ['name', 'expense', 'expense name', 'title'],
    category: ['category', 'type'],
    amount: ['amount', 'value', 'cost'],
    description: ['description', 'details', 'desc'],
  },

  sheetOk() { return typeof XLSX !== 'undefined'; },

  render() {
    const root = document.getElementById('page-excel');
    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Import / Export<small>Excel &amp; CSV import with preview · full backup &amp; restore</small></h2>
      </div>

      <div class="panel">
        <h3>⇧ Import spreadsheet</h3>
        <div class="filter-bar">
          <div class="field"><label>Import into</label>
            <select id="imKind">
              <option value="buy">Buy Transactions</option>
              <option value="sell">Sell Transactions</option>
              <option value="expenses">Expenses</option>
            </select></div>
          <label class="switch-row" style="gap:8px"><input type="checkbox" id="imSkipDup" checked> Skip duplicates (UTR / date+amount+party)</label>
        </div>
        <div class="drop-zone" id="dropZone">
          Drop an <b>.xlsx</b> or <b>.csv</b> file here, or click to choose.<br>
          <small>First row must contain column headers — they are auto-mapped, and you can adjust before importing.</small>
          <input type="file" id="imFile" accept=".xlsx,.xls,.csv" hidden>
        </div>
        <div id="imPreview"></div>
      </div>

      <div class="panel">
        <h3>⇩ Export</h3>
        <div class="btn-row" style="margin-top:4px">
          <button class="btn" id="exXlsx">Excel workbook (all sheets)</button>
          <button class="btn ghost" id="exBuyCsv">Buys CSV</button>
          <button class="btn ghost" id="exSellCsv">Sells CSV</button>
          <button class="btn ghost" id="exExpCsv">Expenses CSV</button>
          <button class="btn ghost" id="exJson">JSON</button>
          <button class="btn ghost" id="exPdf">PDF / Print current page</button>
        </div>
      </div>

      <div class="panel">
        <h3>🛟 Backup &amp; Restore</h3>
        <p style="color:var(--text-dim);font-size:.85rem;margin-bottom:12px">
          A backup is a single JSON file containing every transaction, expense, setting and admin option.
          Keep one somewhere safe — browser storage can be wiped by clearing site data.</p>
        <div class="btn-row" style="margin-top:0">
          <button class="btn" id="bkDownload">Download backup</button>
          <button class="btn ghost" id="bkRestore">Restore from backup…</button>
          <input type="file" id="bkFile" accept=".json" hidden>
        </div>
      </div>`;

    this.bind();
  },

  bind() {
    const $ = id => document.getElementById(id);
    const dz = $('dropZone');
    dz.onclick = () => $('imFile').click();
    dz.ondragover = e => { e.preventDefault(); dz.classList.add('over'); };
    dz.ondragleave = () => dz.classList.remove('over');
    dz.ondrop = e => { e.preventDefault(); dz.classList.remove('over'); if (e.dataTransfer.files[0]) this.readFile(e.dataTransfer.files[0]); };
    $('imFile').onchange = e => { if (e.target.files[0]) this.readFile(e.target.files[0]); e.target.value = ''; };

    $('exXlsx').onclick = () => this.exportWorkbook();
    $('exBuyCsv').onclick = () => this.exportTradesCSV('buy');
    $('exSellCsv').onclick = () => this.exportTradesCSV('sell');
    $('exExpCsv').onclick = () => this.exportExpensesCSV(Store.expenses());
    $('exJson').onclick = () => U.download('p2p-ledger-data.json', Store.exportData(), 'application/json');
    $('exPdf').onclick = () => window.print();

    $('bkDownload').onclick = () => {
      U.download(`p2p-ledger-backup-${U.todayISO()}.json`, Store.exportData(), 'application/json');
      Store.log('backup', 'Manual backup downloaded');
      U.toast('Backup downloaded');
    };
    $('bkRestore').onclick = () => $('bkFile').click();
    $('bkFile').onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      const go = await U.confirm('Restoring replaces ALL current data with the backup file. Continue?');
      if (!go) return;
      const text = await f.text();
      try {
        History.snapshot('Restore backup');
        Store.importData(text);
        App.refreshAll();
      } catch { U.toast('That file is not a valid backup', true); }
      e.target.value = '';
    };
  },

  /* ---------- import pipeline ---------- */
  async readFile(file) {
    const kind = document.getElementById('imKind').value;
    let headers = [], rows = [];
    try {
      if (/\.csv$/i.test(file.name)) {
        const text = await file.text();
        const lines = text.split(/\r?\n/).filter(l => l.trim());
        const parse = l => l.match(/("([^"]|"")*"|[^,]*)(,|$)/g).slice(0, -0)
          .map(c => c.replace(/,$/, '').replace(/^"|"$/g, '').replace(/""/g, '"'));
        headers = parse(lines[0]);
        rows = lines.slice(1).map(parse);
      } else {
        if (!this.sheetOk()) return U.toast('SheetJS library not loaded — use CSV, or add xlsx.full.min.js for offline use', true);
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: 'array', cellDates: true });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, dateNF: 'yyyy-mm-dd' });
        headers = (aoa[0] || []).map(h => String(h ?? ''));
        rows = aoa.slice(1).filter(r => r.some(c => String(c ?? '').trim()));
      }
    } catch { return U.toast('Could not read that file', true); }
    if (!headers.length || !rows.length) return U.toast('File appears to be empty', true);

    // auto map
    const mapping = {};
    this.FIELDS[kind].forEach(f => {
      const aliases = this.ALIASES[f] || [f];
      const idx = headers.findIndex(h => aliases.includes(String(h).trim().toLowerCase()));
      mapping[f] = idx;
    });
    this.pending = { kind, headers, rows, mapping };
    this.renderPreview();
  },

  renderPreview() {
    const { kind, headers, rows, mapping } = this.pending;
    const box = document.getElementById('imPreview');
    const fields = this.FIELDS[kind];

    box.innerHTML = `
      <h3 style="margin:18px 0 10px">Map columns</h3>
      <div class="map-grid">
        ${fields.map(f => `
          <div class="field"><label>${f}</label>
            <select data-map="${f}">
              <option value="-1">— skip —</option>
              ${headers.map((h, i) => `<option value="${i}" ${mapping[f] === i ? 'selected' : ''}>${U.esc(h)}</option>`).join('')}
            </select></div>`).join('')}
      </div>
      <h3 style="margin:18px 0 10px">Preview (first 5 rows of ${rows.length})</h3>
      <div class="table-wrap glass"><table>
        <thead><tr>${fields.map(f => `<th>${f}</th>`).join('')}</tr></thead>
        <tbody id="imPrevBody"></tbody></table></div>
      <div class="btn-row">
        <button class="btn" id="imGo">Import ${rows.length} rows</button>
        <button class="btn ghost" id="imCancel">Cancel</button>
      </div>`;

    const refreshPrev = () => {
      document.getElementById('imPrevBody').innerHTML = rows.slice(0, 5).map(r =>
        `<tr>${fields.map(f => `<td>${U.esc(mapping[f] >= 0 ? r[mapping[f]] : '')}</td>`).join('')}</tr>`).join('');
    };
    box.querySelectorAll('[data-map]').forEach(sel => sel.onchange = () => {
      mapping[sel.dataset.map] = parseInt(sel.value, 10);
      refreshPrev();
    });
    refreshPrev();
    document.getElementById('imGo').onclick = () => this.commit();
    document.getElementById('imCancel').onclick = () => { this.pending = null; box.innerHTML = ''; };
  },

  normDate(v) {
    const s = String(v ?? '').trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/); // DD/MM/YYYY
    if (m) {
      const y = m[3].length === 2 ? '20' + m[3] : m[3];
      return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    }
    const d = new Date(s);
    return isNaN(d) ? '' : d.toISOString().slice(0, 10);
  },

  commit() {
    const { kind, rows, mapping } = this.pending;
    const skipDup = document.getElementById('imSkipDup').checked;
    const get = (r, f) => mapping[f] >= 0 ? r[mapping[f]] : '';
    let added = 0, skipped = 0, bad = 0;

    History.snapshot('Import ' + kind);
    rows.forEach(r => {
      if (kind === 'expenses') {
        const e = {
          id: U.uid(), date: this.normDate(get(r, 'date')),
          name: String(get(r, 'name') || '').trim(),
          category: String(get(r, 'category') || 'Miscellaneous').trim() || 'Miscellaneous',
          amount: U.num(get(r, 'amount')),
          description: String(get(r, 'description') || '').trim(),
        };
        if (!e.date || !e.name || e.amount <= 0) return bad++;
        if (skipDup && Store.expenses().some(x => x.date === e.date && x.name === e.name && U.round2(x.amount) === U.round2(e.amount))) return skipped++;
        Store.expenses().push(e); added++;
        if (!Store.lists().expenseCategories.includes(e.category)) Store.lists().expenseCategories.push(e.category);
        return;
      }

      const qty = U.num(get(r, 'qty')), fees = U.num(get(r, 'fees')), price = U.num(get(r, 'price'));
      const isBuy = kind === 'buy';
      const { netQty, total } = Formulas.tradeCalc(kind, qty, fees, price);
      const tx = {
        id: U.uid(), createdAt: new Date().toISOString(),
        date: this.normDate(get(r, 'date')),
        party: String(get(r, 'party') || '').trim(),
        asset: String(get(r, 'asset') || Store.settings().defaultAsset).trim().toUpperCase(),
        qty, fees, price, netQty,
        total,
        bank: String(get(r, 'bank') || '').trim(),
        mode: String(get(r, 'mode') || '').trim(),
        utr: String(get(r, 'utr') || '').trim(),
        orderNo: String(get(r, 'orderNo') || '').trim(),
        notes: String(get(r, 'notes') || '').trim(),
        tags: [], fav: false,
      };
      if (!tx.date || qty <= 0 || price <= 0) return bad++;
      if (skipDup && Store.isDuplicate(kind, tx)) return skipped++;
      if (tx.asset && !Store.lists().assets.includes(tx.asset)) Store.lists().assets.push(tx.asset);
      if (tx.bank && !Store.lists().banks.includes(tx.bank)) Store.lists().banks.push(tx.bank);
      if (tx.mode && !Store.lists().modes.includes(tx.mode)) Store.lists().modes.push(tx.mode);
      (isBuy ? Store.buys() : Store.sells()).push(tx);
      added++;
    });

    Store.log('import', `${kind}: ${added} added, ${skipped} duplicates skipped, ${bad} invalid`);
    Store.save();
    this.pending = null;
    document.getElementById('imPreview').innerHTML = '';
    U.toast(`Imported ${added} rows · ${skipped} duplicates skipped · ${bad} invalid`);
    App.refreshAll();
  },

  /* ---------- exports ---------- */
  csv(rows) {
    return rows.map(r => r.map(c => {
      const s = String(c ?? '');
      return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(',')).join('\n');
  },

  tradeRows(kind) {
    const list = kind === 'buy' ? Store.buys() : Store.sells();
    const head = ['Date', kind === 'buy' ? 'Seller' : 'Buyer', 'Asset', 'Quantity', 'Fees', 'Net Qty', 'Price', 'Total', 'Bank', 'Mode', 'UTR', 'Binance Order No', 'Notes', 'Tags'];
    const body = list.map(t => [t.date, t.party, t.asset, t.qty, t.fees, t.netQty, t.price, t.total, t.bank, t.mode, t.utr, t.orderNo, t.notes, (t.tags || []).join('|')]);
    return [head, ...body];
  },

  exportTradesCSV(kind) {
    U.download(`${kind}-transactions.csv`, this.csv(this.tradeRows(kind)), 'text/csv');
    U.toast('CSV downloaded');
  },

  exportExpensesCSV(list) {
    const rows = [['Date', 'Name', 'Category', 'Amount', 'Description'],
      ...list.map(e => [e.date, e.name, e.category, e.amount, e.description])];
    U.download('expenses.csv', this.csv(rows), 'text/csv');
    U.toast('CSV downloaded');
  },

  exportWorkbook() {
    if (!this.sheetOk()) return U.toast('SheetJS not loaded — use CSV exports instead', true);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(this.tradeRows('buy')), 'Buys');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(this.tradeRows('sell')), 'Sells');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([
      ['Date', 'Name', 'Category', 'Amount', 'Description'],
      ...Store.expenses().map(e => [e.date, e.name, e.category, e.amount, e.description]),
    ]), 'Expenses');
    XLSX.writeFile(wb, `p2p-ledger-${U.todayISO()}.xlsx`);
    U.toast('Excel workbook downloaded');
  },

  /* Tax report export used by tax.js */
  exportTax(report, fmt) {
    if (!report) return U.toast('Generate a report first', true);
    const T = report.totals;
    const overview = [
      ['Tax Report', report.label], [],
      ['Total Buy', T.buy], ['Total Sell', T.sell], ['Total Expenses', T.expenses],
      ['Gross Profit', T.gross], ['Net Profit', T.net], [],
    ];
    const section = (title, obj, cols) => [
      [title], ['Key', ...cols],
      ...Object.entries(obj).filter(([k]) => k !== '—').map(([k, t]) => [k, ...cols.map(c => t[c.toLowerCase().replace(' ', '')] ?? t[c] ?? '')]),
      [],
    ];
    const flat = key => Object.entries(report[key]).filter(([k]) => k !== '—').map(([k, t]) => [k, t.buy, t.sell, t.gross, t.net, t.trades]);
    const sheetify = key => [['Key', 'Buy', 'Sell', 'Gross Profit', 'Net Profit', 'Trades'], ...flat(key)];

    if (fmt === 'csv' || !this.sheetOk()) {
      const rows = [
        ...overview,
        ['BANK-WISE'], ...sheetify('byBank'), [],
        ['ASSET-WISE'], ...sheetify('byAsset'), [],
        ['PAYMENT MODES'], ...sheetify('byMode'), [],
        ['MONTHLY'], ...sheetify('byMonth'), [],
        ['QUARTERLY'], ...sheetify('byQuarter'), [],
        ['YEARLY'], ...sheetify('byYear'),
      ];
      U.download(`tax-report-${U.todayISO()}.csv`, this.csv(rows), 'text/csv');
      return U.toast('Tax report CSV downloaded');
    }
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(overview), 'Overview');
    ['byBank', 'byAsset', 'byMode', 'byMonth', 'byQuarter', 'byYear'].forEach(k =>
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sheetify(k)), k.replace('by', '')));
    XLSX.writeFile(wb, `tax-report-${U.todayISO()}.xlsx`);
    U.toast('Tax report Excel downloaded');
  },
};
