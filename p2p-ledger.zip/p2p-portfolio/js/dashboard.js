/* ============================================================
   dashboard.js — cards, filters and all Chart.js visualisations
   ============================================================ */
'use strict';

const Dashboard = {
  filters: { mode: 'month', from: '', to: '', asset: '' },

  CARD_DEFS: [
    // [id, label, fn(todayT, monthT, yearT, scopeT)]
    ['todayBuy', "Today's Buy", t => [U.fmtMoney(t.today.buy), '']],
    ['todaySell', "Today's Sell", t => [U.fmtMoney(t.today.sell), '']],
    ['todayProfit', "Today's Profit", t => [U.fmtMoney(t.today.net), t.today.net >= 0 ? 'pos' : 'neg']],
    ['monthBuy', 'Monthly Buy', t => [U.fmtMoney(t.month.buy), '']],
    ['monthSell', 'Monthly Sell', t => [U.fmtMoney(t.month.sell), '']],
    ['monthProfit', 'Monthly Profit', t => [U.fmtMoney(t.month.net), t.month.net >= 0 ? 'pos' : 'neg']],
    ['yearBuy', 'Yearly Buy', t => [U.fmtMoney(t.year.buy), '']],
    ['yearSell', 'Yearly Sell', t => [U.fmtMoney(t.year.sell), '']],
    ['yearProfit', 'Yearly Profit', t => [U.fmtMoney(t.year.net), t.year.net >= 0 ? 'pos' : 'neg']],
    ['holdings', 'Total Holdings', t => [U.fmtNum(t.all.holdings, 4), '']],
    ['expenses', 'Expenses (period)', t => [U.fmtMoney(t.scope.expenses), 'neg']],
    ['netProfit', 'Net Profit (period)', t => [U.fmtMoney(t.scope.net), t.scope.net >= 0 ? 'pos' : 'neg']],
  ],

  render() {
    const root = document.getElementById('page-dashboard');
    const L = Store.lists();
    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Dashboard<small>Live overview of your P2P trading book</small></h2>
        <div class="filter-bar" style="margin:0">
          <div class="field"><label>Period</label>
            <select id="dbMode">
              <option value="day">Today</option><option value="week">This Week</option>
              <option value="month">This Month</option><option value="year">This Year</option>
              <option value="custom">Custom Range</option>
            </select></div>
          <div class="field" id="dbWrapFrom" hidden><label>From</label><input type="date" id="dbFrom"></div>
          <div class="field" id="dbWrapTo" hidden><label>To</label><input type="date" id="dbTo"></div>
          <div class="field"><label>Asset</label><select id="dbAsset"><option value="">All</option>${U.optionList(L.assets, this.filters.asset)}</select></div>
        </div>
      </div>

      <div class="cards-grid" id="dbCards"></div>

      <div class="charts-grid">
        ${[
          ['chDaily', 'Daily Buy · Sell · Profit'],
          ['chMonthlyProfit', 'Monthly Profit'],
          ['chPayModes', 'Payment Method Distribution'],
          ['chBanks', 'Bank-wise Transactions'],
          ['chAssetProfit', 'Asset-wise Profit'],
          ['chPortfolio', 'Running Portfolio (holdings)'],
          ['chExpenses', 'Expenses by Category'],
          ['chProfitTrend', 'Profit Trend (cumulative)'],
          ['chBuySell', 'Buy vs Sell'],
          ['chIncomeExpense', 'Income vs Expense'],
        ].map(([id, t]) => `<div class="chart-panel card"><h4>${t}</h4><div class="chart-body"><canvas id="${id}"></canvas></div></div>`).join('')}
      </div>

      <div class="panel" style="margin-top:20px">
        <h3>Recent Transactions</h3>
        <div id="dbRecent"></div>
      </div>`;

    const $ = id => document.getElementById(id);
    $('dbMode').value = this.filters.mode;
    const sync = () => {
      this.filters.mode = $('dbMode').value;
      this.filters.asset = $('dbAsset').value;
      const custom = this.filters.mode === 'custom';
      $('dbWrapFrom').hidden = $('dbWrapTo').hidden = !custom;
      if (custom) { this.filters.from = $('dbFrom').value; this.filters.to = $('dbTo').value; }
      this.refresh();
    };
    ['dbMode', 'dbAsset', 'dbFrom', 'dbTo'].forEach(f => $(f).addEventListener('change', sync));
    this.refresh();
  },

  scopeRange() {
    const today = U.todayISO();
    switch (this.filters.mode) {
      case 'day': return [today, today];
      case 'week': {
        const d = new Date(); const dow = (d.getDay() + 6) % 7;
        const mon = new Date(d); mon.setDate(d.getDate() - dow);
        return [mon.toISOString().slice(0, 10), today];
      }
      case 'year': return [today.slice(0, 4) + '-01-01', today];
      case 'custom': return [this.filters.from, this.filters.to];
      default: return [today.slice(0, 7) + '-01', today]; // month
    }
  },

  refresh() {
    if (!document.getElementById('dbCards')) return;
    const asset = this.filters.asset;
    const today = U.todayISO();
    const [from, to] = this.scopeRange();

    const T = {
      today: Calc.totals(Calc.scope({ from: today, to: today, asset })),
      month: Calc.totals(Calc.scope({ from: today.slice(0, 7) + '-01', to: today, asset })),
      year: Calc.totals(Calc.scope({ from: today.slice(0, 4) + '-01-01', to: today, asset })),
      all: Calc.totals(Calc.scope({ asset })),
      scope: Calc.totals(Calc.scope({ from, to, asset })),
    };

    // cards, honoring admin hide + order
    const A = Store.admin();
    let defs = this.CARD_DEFS.filter(([id]) => !A.hiddenCards.includes(id));
    if (A.cardOrder.length) {
      defs = [...defs].sort((a, b) => {
        const ia = A.cardOrder.indexOf(a[0]), ib = A.cardOrder.indexOf(b[0]);
        return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
      });
    }
    document.getElementById('dbCards').innerHTML = defs.map(([id, label, fn]) => {
      const [val, cls] = fn(T);
      return `<div class="stat-card card"><div class="stat-label">${label}</div><div class="stat-value ${cls}">${val}</div></div>`;
    }).join('');

    this.drawCharts(from, to, asset);
    this.renderRecent();
  },

  drawCharts(from, to, asset) {
    if (!Charts.ok()) return;
    const scope = Calc.scope({ from, to, asset });
    const byDay = Calc.byDay(scope);
    const days = Object.keys(byDay);
    const dayLabels = days.map(d => U.fmtDate(d));

    // 1. line: daily buy/sell/profit
    Charts.line('chDaily', dayLabels, [
      { label: 'Buy', data: days.map(d => byDay[d].buy) },
      { label: 'Sell', data: days.map(d => byDay[d].sell) },
      { label: 'Profit', data: days.map(d => byDay[d].net) },
    ]);

    // 2. bar: monthly profit (whole book for context)
    const byMonthAll = Calc.byMonth(Calc.scope({ asset }));
    const months = Object.keys(byMonthAll);
    Charts.bars('chMonthlyProfit', months, [{
      label: 'Net Profit', data: months.map(m => byMonthAll[m].net),
      colors: months.map(m => byMonthAll[m].net >= 0 ? Charts.palette()[0] + 'cc' : '#ff6b7acc'),
    }]);

    // 3. pie: payment modes (by trade count)
    const modeCount = {};
    [...scope.buys, ...scope.sells].forEach(t => modeCount[t.mode || '—'] = (modeCount[t.mode || '—'] || 0) + 1);
    Charts.pie('chPayModes', Object.keys(modeCount), Object.values(modeCount));

    // 4. doughnut: bank-wise value
    const bankVal = {};
    [...scope.buys, ...scope.sells].forEach(t => bankVal[t.bank || '—'] = (bankVal[t.bank || '—'] || 0) + t.total);
    Charts.pie('chBanks', Object.keys(bankVal), Object.values(bankVal).map(v => U.round2(v)), true);

    // 5. bar: asset-wise profit
    const byAsset = Calc.byAsset(scope);
    const assets = Object.keys(byAsset).filter(k => k !== '—');
    Charts.bars('chAssetProfit', assets, [{ label: 'Gross Profit', data: assets.map(a => byAsset[a].gross) }]);

    // 6. area: running portfolio holdings over time (whole history)
    const events = [...Store.buys().filter(t => !asset || t.asset === asset).map(t => ({ d: t.date, q: t.netQty })),
                    ...Store.sells().filter(t => !asset || t.asset === asset).map(t => ({ d: t.date, q: -t.netQty }))]
      .sort((a, b) => a.d.localeCompare(b.d));
    let run = 0;
    const pLabels = [], pData = [];
    const perDay = {};
    events.forEach(e => perDay[e.d] = (perDay[e.d] || 0) + e.q);
    Object.keys(perDay).sort().forEach(d => { run += perDay[d]; pLabels.push(U.fmtDate(d)); pData.push(U.round2(run)); });
    Charts.area('chPortfolio', pLabels, 'Holdings', pData);

    // 7. expenses by category
    const catVal = {};
    scope.expenses.forEach(e => catVal[e.category] = (catVal[e.category] || 0) + e.amount);
    Charts.pie('chExpenses', Object.keys(catVal), Object.values(catVal).map(v => U.round2(v)), true);

    // 8. cumulative profit trend
    let cum = 0;
    Charts.line('chProfitTrend', dayLabels, [{
      label: 'Cumulative Net Profit', data: days.map(d => U.round2(cum += byDay[d].net)), fill: true,
    }]);

    // 9. buy vs sell bars
    Charts.bars('chBuySell', dayLabels, [
      { label: 'Buy', data: days.map(d => byDay[d].buy) },
      { label: 'Sell', data: days.map(d => byDay[d].sell) },
    ]);

    // 10. income vs expense (monthly)
    Charts.bars('chIncomeExpense', months, [
      { label: 'Gross Profit', data: months.map(m => byMonthAll[m].gross) },
      { label: 'Expenses', data: months.map(m => byMonthAll[m].expenses), colors: '#ff6b7acc' },
    ]);
  },

  renderRecent() {
    const recent = [
      ...Store.buys().map(t => ({ ...t, kind: 'Buy' })),
      ...Store.sells().map(t => ({ ...t, kind: 'Sell' })),
    ].sort((a, b) => (b.createdAt || b.date).localeCompare(a.createdAt || a.date)).slice(0, 8);

    U.renderTable(document.getElementById('dbRecent'), {
      rows: recent, pageSize: 8,
      columns: [
        { key: 'date', label: 'Date', render: r => U.fmtDate(r.date) },
        { key: 'kind', label: 'Type', render: r => `<span class="tag">${r.kind}</span>` },
        { key: 'party', label: 'Party' },
        { key: 'asset', label: 'Asset' },
        { key: 'netQty', label: 'Net Qty', num: true, render: r => U.fmtNum(r.netQty, 4) },
        { key: 'total', label: 'Amount', num: true, render: r => `<span class="${r.kind === 'Sell' ? 'pos' : ''}">${U.fmtMoney(r.total)}</span>` },
      ],
      onRowClick: id => {
        const isBuy = Store.buys().some(t => t.id === id);
        App.go(isBuy ? 'buy' : 'sell');
        (isBuy ? Buy : Sell).edit(id);
      },
    });
  },
};
