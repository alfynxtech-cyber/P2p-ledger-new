/* ============================================================
   formulas.js — every calculation in the app is driven from here.
   Admin Panel → Calculation Formulas edits these expressions.
   Uses a small safe parser (no eval / Function), so a typo can
   never run arbitrary code — bad formulas fall back to default.
   ============================================================ */
'use strict';

const Formulas = {

  /* id → label, default expression, allowed variables, sample values for live testing */
  DEFS: {
    netQty: {
      label: 'Net Quantity', expr: 'qty - fees',
      note: 'Every Buy & Sell entry',
      sample: { qty: 500, fees: 2.5, price: 91.4 },
    },
    buyTotal: {
      label: 'Buy — Total Amount Paid', expr: 'price * qty',
      note: 'Buy entries',
      sample: { qty: 500, fees: 2.5, price: 91.4, netQty: 497.5 },
    },
    sellTotal: {
      label: 'Sell — Total Amount Received', expr: 'price * netQty',
      note: 'Sell entries',
      sample: { qty: 500, fees: 2.5, price: 91.4, netQty: 497.5 },
    },
    feeValue: {
      label: 'Fee Value (in currency)', expr: 'fees * price',
      note: 'Used by fee-based profit formulas',
      sample: { qty: 500, fees: 2.5, price: 91.4, netQty: 497.5 },
    },
    grossProfit: {
      label: 'Gross Profit', expr: 'sell - buy',
      note: 'Profit, Summary, Tax, Dashboard',
      sample: { sell: 9200, buy: 9000, buyFees: 90, sellFees: 46, expenses: 500, buyQty: 99, sellQty: 98.5 },
    },
    netProfit: {
      label: 'Net Profit', expr: 'gross - expenses',
      note: 'Profit, Summary, Tax, Dashboard',
      sample: { gross: 200, sell: 9200, buy: 9000, buyFees: 90, sellFees: 46, expenses: 500 },
    },
    roi: {
      label: 'ROI %', expr: 'net / buy * 100',
      note: 'Profit, Summary, Tax',
      sample: { net: -300, gross: 200, sell: 9200, buy: 9000, expenses: 500 },
    },
    holdings: {
      label: 'Current Holdings', expr: 'buyQty - sellQty',
      note: 'Dashboard, Summary',
      sample: { buyQty: 99, sellQty: 98.5 },
    },
    avgBuy: {
      label: 'Average Buy Price', expr: 'buy / buyQty',
      note: 'Summary, Profit',
      sample: { buy: 9000, buyQty: 99 },
    },
    avgSell: {
      label: 'Average Sell Price', expr: 'sell / sellQty',
      note: 'Summary, Profit',
      sample: { sell: 9200, sellQty: 98.5 },
    },
  },

  vars(id) { return Object.keys(this.DEFS[id].sample); },

  /* current expression: custom → legacy profit-formula setting → default */
  get(id) {
    const custom = (Store.admin().formulas || {})[id];
    if (custom && String(custom).trim()) return String(custom).trim();
    if (id === 'grossProfit') {
      const A = Store.admin();
      if (A.profitFormula === 'sell-buy-fees') return 'sell - (buy + buyFees + sellFees)';
      if (A.profitFormula === 'custom' && A.customFormula) return A.customFormula;
    }
    return this.DEFS[id].expr;
  },

  isCustom(id) { return this.get(id).replace(/\s+/g, '') !== this.DEFS[id].expr.replace(/\s+/g, ''); },

  /* evaluate a named formula; invalid → default; non-finite (÷0) → 0 */
  run(id, vars) {
    let v;
    try { v = this.evalExpr(this.get(id), vars); }
    catch { v = this.evalExpr(this.DEFS[id].expr, vars); }
    return Number.isFinite(v) ? v : 0;
  },

  /* validate an expression against the sample data → {ok, value | error} */
  validate(id, expr) {
    try {
      if (!String(expr).trim()) throw new Error('Formula is empty');
      const v = this.evalExpr(expr, this.DEFS[id].sample);
      return { ok: true, value: Number.isFinite(v) ? v : 0 };
    } catch (e) { return { ok: false, error: e.message }; }
  },

  /* per-trade helper used by Buy, Sell, Excel import and recalculation */
  tradeCalc(kind, qty, fees, price) {
    qty = U.num(qty); fees = U.num(fees); price = U.num(price);
    const netQty = Math.round(this.run('netQty', { qty, fees, price }) * 1e4) / 1e4;
    const total = U.round2(this.run(kind === 'buy' ? 'buyTotal' : 'sellTotal', { qty, fees, price, netQty }));
    return { netQty, total };
  },

  /* re-apply current formulas to every stored trade */
  recalcAll() {
    let n = 0;
    [['buy', Store.buys()], ['sell', Store.sells()]].forEach(([kind, list]) => list.forEach(t => {
      const c = this.tradeCalc(kind, t.qty, t.fees, t.price);
      t.netQty = c.netQty; t.total = c.total; n++;
    }));
    return n;
  },

  /* ---------- safe expression parser ----------
     numbers, variables, + - * / % ( ), and abs/min/max/round/floor/ceil */
  FN: { abs: Math.abs, min: Math.min, max: Math.max, round: Math.round, floor: Math.floor, ceil: Math.ceil },

  evalExpr(input, vars) {
    const src = String(input).replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-');
    const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

    const toks = [];
    const re = /\s*(?:(\d+\.?\d*|\.\d+)|([A-Za-z_]\w*)|([-+*/%(),]))/y;
    let pos = 0;
    while (pos < src.length) {
      re.lastIndex = pos;
      const m = re.exec(src);
      if (!m) {
        if (/^\s*$/.test(src.slice(pos))) break;
        throw new Error('Unexpected character "' + src.slice(pos).trim()[0] + '"');
      }
      toks.push(m[1] !== undefined ? { n: parseFloat(m[1]) } : m[2] ? { id: m[2] } : { op: m[3] });
      pos = re.lastIndex;
    }

    let i = 0;
    const peek = () => toks[i];
    const isOp = (...ops) => peek() && ops.includes(peek().op);
    const self = this;

    function expr() {
      let v = term();
      while (isOp('+', '-')) { const o = toks[i++].op; const r = term(); v = o === '+' ? v + r : v - r; }
      return v;
    }
    function term() {
      let v = unary();
      while (isOp('*', '/', '%')) {
        const o = toks[i++].op; const r = unary();
        v = o === '*' ? v * r : o === '/' ? v / r : v % r;
      }
      return v;
    }
    function unary() {
      if (isOp('-')) { i++; return -unary(); }
      if (isOp('+')) { i++; return unary(); }
      return primary();
    }
    function primary() {
      const t = toks[i++];
      if (!t) throw new Error('Formula ends unexpectedly');
      if (t.n !== undefined) return t.n;
      if (t.id) {
        if (isOp('(')) {
          if (!own(self.FN, t.id)) throw new Error('Unknown function "' + t.id + '"');
          i++;
          const args = [];
          if (!isOp(')')) { do { args.push(expr()); } while (isOp(',') && i++); }
          if (!isOp(')')) throw new Error('Missing ")"');
          i++;
          return self.FN[t.id](...args);
        }
        if (!own(vars, t.id)) throw new Error('Unknown variable "' + t.id + '"');
        return U.num(vars[t.id]);
      }
      if (t.op === '(') {
        const v = expr();
        if (!isOp(')')) throw new Error('Missing ")"');
        i++;
        return v;
      }
      throw new Error('Unexpected "' + t.op + '"');
    }

    const out = expr();
    if (i < toks.length) throw new Error('Unexpected "' + (toks[i].op || toks[i].id || toks[i].n) + '"');
    return out;
  },
};
