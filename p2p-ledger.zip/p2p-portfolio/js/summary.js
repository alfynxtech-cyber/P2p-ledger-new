/* ============================================================
   summary.js — Summary page: filters + full metric readout
   ============================================================ */
'use strict';

const Summary = {
  mode: 'range', // date | range | month | quarter | year
  values: { date: '', from: '', to: '', month: '', quarter: '', year: '', asset: '' },

  render() {
    const root = document.getElementById('page-summary');
    const L = Store.lists();
    const years = [...new Set([...Store.buys(), ...Store.sells()].map(t => U.yearKey(t.date)))].sort().reverse();

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Summary<small>Complete position &amp; performance snapshot for any period</small></h2>
      </div>

      <div class="filter-bar">
        <div class="field"><label>Period type</label>
          <select id="smMode">
            <option value="range">Date Range</option>
            <option value="date">Single Date</option>
            <option value="month">Month</option>
            <option value="quarter">Quarter</option>
            <option value="year">Year</option>
          </select></div>
        <div class="field" id="smWrapDate" hidden><label>Date</label><input type="date" id="smDate"></div>
        <div class="field" id="smWrapFrom"><label>From</label><input type="date" id="smFrom"></div>
        <div class="field" id="smWrapTo"><label>To</label><input type="date" id="smTo"></div>
        <div class="field" id="smWrapMonth" hidden><label>Month</label><input type="month" id="smMonth" value="${U.todayISO().slice(0, 7)}"></div>
        <div class="field" id="smWrapQuarter" hidden><label>Quarter</label>
          <select id="smQuarter">${years.flatMap(y => [1, 2, 3, 4].map(q => `<option value="${y}-Q${q}">${y} Q${q}</option>`)).join('') || '<option value="">No data</option>'}</select></div>
        <div class="field" id="smWrapYear" hidden><label>Year</label>
          <select id="smYear">${years.map(y => `<option>${y}</option>`).join('') || '<option value="">No data</option>'}</select></div>
        <div class="field"><label>Asset</label><select id="smAsset"><option value="">All</option>${U.optionList(L.assets)}</select></div>
      </div>

      <div class="cards-grid" id="smCards"></div>
      <div class="panel"><h3>By Asset</h3><div id="smAssetTable"></div></div>`;

    const $ = id => document.getElementById(id);
    $('smMode').value = this.mode;
    const sync = () => {
      this.mode = $('smMode').value;
      ['Date', 'From', 'To', 'Month', 'Quarter', 'Year'].forEach(w => $('smWrap' + w).hidden = true);
      if (this.mode === 'date') $('smWrapDate').hidden = false;
      if (this.mode === 'range') { $('smWrapFrom').hidden = $('smWrapTo').hidden = false; }
      if (this.mode === 'month') $('smWrapMonth').hidden = false;
      if (this.mode === 'quarter') $('smWrapQuarter').hidden = false;
      if (this.mode === 'year') $('smWrapYear').hidden = false;
      this.draw();
    };
    ['smMode', 'smDate', 'smFrom', 'smTo', 'smMonth', 'smQuarter', 'smYear', 'smAsset'].forEach(f =>
      $(f).addEventListener('change', sync));
    sync();
  },

  currentRange() {
    const $ = id => document.getElementById(id);
    switch (this.mode) {
      case 'date': { const d = $('smDate').value; return d ? [d, d] : ['', '']; }
      case 'month': { const m = $('smMonth').value; return m ? [m + '-01', m + '-31'] : ['', '']; }
      case 'quarter': {
        const v = $('smQuarter').value; if (!v) return ['', ''];
        const [y, q] = v.split('-Q');
        const sm = (q - 1) * 3 + 1;
        return [`${y}-${String(sm).padStart(2, '0')}-01`, `${y}-${String(sm + 2).padStart(2, '0')}-31`];
      }
      case 'year': { const y = $('smYear').value; return y ? [y + '-01-01', y + '-12-31'] : ['', '']; }
      default: return [$('smFrom').value, $('smTo').value];
    }
  },

  draw() {
    const [from, to] = this.currentRange();
    const asset = document.getElementById('smAsset').value;
    const scope = Calc.scope({ from, to, asset });
    const T = Calc.totals(scope);

    const cards = [
      ['Total Buy', U.fmtMoney(T.buy), ''],
      ['Total Sell', U.fmtMoney(T.sell), ''],
      ['Qty Bought', U.fmtNum(T.buyQty, 4), ''],
      ['Qty Sold', U.fmtNum(T.sellQty, 4), ''],
      ['Current Holdings', U.fmtNum(T.holdings, 4), T.holdings >= 0 ? '' : 'neg'],
      ['Avg Buy Price', U.fmtMoney(T.avgBuy), ''],
      ['Avg Sell Price', U.fmtMoney(T.avgSell), ''],
      ['Gross Profit', U.fmtMoney(T.gross), T.gross >= 0 ? 'pos' : 'neg'],
      ['Expenses', U.fmtMoney(T.expenses), 'neg'],
      ['Net Profit', U.fmtMoney(T.net), T.net >= 0 ? 'pos' : 'neg'],
      ['ROI', U.fmtNum(T.roi) + '%', T.roi >= 0 ? 'pos' : 'neg'],
      ['Number of Trades', T.trades, ''],
    ];
    document.getElementById('smCards').innerHTML = cards.map(([l, v, cls]) =>
      `<div class="stat-card card"><div class="stat-label">${l}</div><div class="stat-value ${cls}">${v}</div></div>`).join('');

    const byAsset = Calc.byAsset(scope);
    const rows = Object.entries(byAsset).filter(([k]) => k !== '—').map(([k, t]) => ({ id: k, asset: k, ...t }));
    U.renderTable(document.getElementById('smAssetTable'), {
      rows,
      columns: [
        { key: 'asset', label: 'Asset' },
        { key: 'buyQty', label: 'Bought', num: true, render: r => U.fmtNum(r.buyQty, 4) },
        { key: 'sellQty', label: 'Sold', num: true, render: r => U.fmtNum(r.sellQty, 4) },
        { key: 'holdings', label: 'Holding', num: true, render: r => U.fmtNum(r.holdings, 4) },
        { key: 'avgBuy', label: 'Avg Buy', num: true, render: r => U.fmtMoney(r.avgBuy) },
        { key: 'avgSell', label: 'Avg Sell', num: true, render: r => U.fmtMoney(r.avgSell) },
        { key: 'gross', label: 'Gross P/L', num: true, render: r => `<span class="${r.gross >= 0 ? 'pos' : 'neg'}">${U.fmtMoney(r.gross)}</span>` },
      ],
    });
  },
};
