/* ============================================================
   settings.js — user preferences (applied live)
   ============================================================ */
'use strict';

const Settings = {

  applyAll() {
    const s = Store.settings();
    document.documentElement.dataset.theme = s.theme;
    document.documentElement.style.setProperty('--accent', s.accentColor);
    document.documentElement.style.setProperty('--font', s.font);
    document.documentElement.style.setProperty('--fs', s.fontSize + 'px');
    document.body.classList.toggle('no-anim', !s.animations);
    if (typeof Effects !== 'undefined') Effects.apply();
  },

  render() {
    const root = document.getElementById('page-settings');
    const s = Store.settings();
    const L = Store.lists();

    root.innerHTML = `
      <div class="page-head"><h2 class="page-title">Settings<small>Everything applies instantly and is saved automatically</small></h2></div>

      <div class="settings-grid">
        <div class="panel">
          <h3>🎨 Appearance</h3>
          <div class="field"><label>Theme</label>
            <select id="stTheme"><option value="dark">Dark</option><option value="light">Light</option></select></div>
          <div class="field" style="margin-top:10px"><label>Accent Color</label><input type="color" id="stAccent" value="${s.accentColor}"></div>
          <div class="field" style="margin-top:10px"><label>Font</label>
            <select id="stFont">
              <option value="'Segoe UI', system-ui, sans-serif">Segoe UI / System</option>
              <option value="Georgia, 'Times New Roman', serif">Georgia (serif)</option>
              <option value="'Trebuchet MS', Verdana, sans-serif">Trebuchet</option>
              <option value="'Courier New', monospace">Monospace</option>
            </select></div>
          <div class="field" style="margin-top:10px"><label>Font Size: <span id="stFsVal">${s.fontSize}px</span></label>
            <input type="range" min="12" max="19" id="stFontSize" value="${s.fontSize}"></div>
          <div class="switch-row"><span>Animations</span><input type="checkbox" id="stAnim" ${s.animations ? 'checked' : ''}></div>
        </div>

        <div class="panel">
          <h3>🌐 Locale &amp; formats</h3>
          <div class="field"><label>Currency Symbol</label><input id="stCurrency" value="${U.esc(s.currencySymbol)}" maxlength="4"></div>
          <div class="field" style="margin-top:10px"><label>Date Format</label>
            <select id="stDateFmt">
              <option>DD/MM/YYYY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option>
            </select></div>
          <div class="field" style="margin-top:10px"><label>Number Format</label>
            <select id="stNumFmt">
              <option value="indian">Indian (1,00,000)</option>
              <option value="international">International (100,000)</option>
            </select></div>
        </div>

        <div class="panel">
          <h3>⚡ Defaults</h3>
          <div class="field"><label>Default Asset</label><select id="stDefAsset">${U.optionList(L.assets, s.defaultAsset)}</select></div>
          <div class="field" style="margin-top:10px"><label>Default Bank</label><select id="stDefBank"><option value="">—</option>${U.optionList(L.banks, s.defaultBank)}</select></div>
          <div class="field" style="margin-top:10px"><label>Default Payment Mode</label><select id="stDefMode">${U.optionList(L.modes, s.defaultMode)}</select></div>
        </div>

        <div class="panel">
          <h3>💾 Data</h3>
          <div class="switch-row"><span>Auto Save (debounced after edits)</span><input type="checkbox" id="stAutoSave" ${s.autoSave ? 'checked' : ''}></div>
          <div class="switch-row"><span>Auto Backup reminder weekly</span><input type="checkbox" id="stAutoBackup" ${s.autoBackup ? 'checked' : ''}></div>
          <p style="color:var(--text-dim);font-size:.8rem;margin-top:8px">
            Data is stored permanently in this browser's local storage and survives refresh and restart.
            Use Import/Export → Backup for an off-browser copy.</p>
        </div>
      </div>`;

    const $ = id => document.getElementById(id);
    $('stTheme').value = s.theme;
    $('stFont').value = s.font;
    $('stDateFmt').value = s.dateFormat;
    $('stNumFmt').value = s.numberFormat;

    const upd = (key, val) => {
      Store.settings()[key] = val;
      Store.save();
      this.applyAll();
      Store.log('settings', key + ' changed');
    };
    $('stTheme').onchange = e => { upd('theme', e.target.value); Dashboard.refresh(); };
    $('stAccent').oninput = e => { upd('accentColor', e.target.value); };
    $('stAccent').onchange = () => Dashboard.refresh();
    $('stFont').onchange = e => upd('font', e.target.value);
    $('stFontSize').oninput = e => { $('stFsVal').textContent = e.target.value + 'px'; upd('fontSize', +e.target.value); };
    $('stAnim').onchange = e => upd('animations', e.target.checked);
    $('stCurrency').oninput = U.debounce(e => { upd('currencySymbol', e.target.value || '₹'); App.refreshAll(); }, 400);
    $('stDateFmt').onchange = e => { upd('dateFormat', e.target.value); App.refreshAll(); };
    $('stNumFmt').onchange = e => { upd('numberFormat', e.target.value); App.refreshAll(); };
    $('stDefAsset').onchange = e => upd('defaultAsset', e.target.value);
    $('stDefBank').onchange = e => upd('defaultBank', e.target.value);
    $('stDefMode').onchange = e => upd('defaultMode', e.target.value);
    $('stAutoSave').onchange = e => upd('autoSave', e.target.checked);
    $('stAutoBackup').onchange = e => upd('autoBackup', e.target.checked);
  },
};
