/* ============================================================
   admin.js — password-protected Admin Panel
   ============================================================ */
'use strict';

const Admin = {
  unlocked: false,

  render() {
    const root = document.getElementById('page-admin');
    if (!this.unlocked) return this.renderLock(root);

    const L = Store.lists();
    const A = Store.admin();
    const G = Effects.cfg('glow');
    const B = Effects.cfg('bgIcons');

    const listEditor = (title, key, extra = '') => `
      <div class="panel">
        <h3>${title}</h3>
        <div class="manage-list" id="ml-${key}">
          ${L[key].map((item, i) => `
            <div class="manage-row">
              <span>${U.esc(item)}</span>
              ${extra === 'fav' ? `<button class="icon-btn fav ${(key === 'banks' ? L.favBanks : L.favAssets).includes(item) ? 'on' : ''}" data-fav="${key}:${i}" title="Favourite">★</button>` : ''}
              <button class="icon-btn" data-edit="${key}:${i}" title="Rename">✎</button>
              <button class="icon-btn" data-del="${key}:${i}" title="Delete">🗑</button>
            </div>`).join('')}
        </div>
        <div class="btn-row" style="margin-top:10px">
          <input id="add-${key}" placeholder="Add new…" style="flex:1;padding:9px 12px;border-radius:10px;border:1px solid var(--border);background:var(--input-bg);color:var(--text)">
          <button class="btn small" data-add="${key}">Add</button>
        </div>
      </div>`;

    root.innerHTML = `
      <div class="page-head">
        <h2 class="page-title">Admin Panel<small>Manage master lists, formulas, layout and data</small></h2>
        <button class="btn ghost small" id="adLock">🔒 Lock</button>
      </div>

      <div class="settings-grid">
        ${listEditor('Assets', 'assets', 'fav')}
        ${listEditor('Banks', 'banks', 'fav')}
        ${listEditor('Payment Modes', 'modes')}
        ${listEditor('Expense Categories', 'expenseCategories')}

        <div class="panel" style="grid-column:1/-1">
          <h3>∑ Calculation Formulas</h3>
          <p class="hint" style="color:var(--text-dim);font-size:.8rem;margin-bottom:12px">
            Edit any calculation used across Buy, Sell, Dashboard, Profit, Summary and Tax.
            Tap a variable to insert it. Operators: <code>+ − × ÷ %</code>, brackets, and <code>abs min max round floor ceil</code>.
            A broken formula automatically falls back to its default.</p>
          <div id="fmList">
            ${Object.entries(Formulas.DEFS).map(([id, d]) => `
              <div class="fm-row" data-fm="${id}">
                <div class="fm-head"><b>${d.label}</b><span class="fm-note">${d.note}</span><span class="fm-badge" hidden>edited</span></div>
                <div class="fm-line">
                  <input class="fm-input" spellcheck="false" value="${U.esc(Formulas.get(id))}">
                  <button class="btn ghost small" data-fm-reset="${id}">Reset</button>
                </div>
                <div class="fm-vars">${Formulas.vars(id).map(v => `<button class="fm-var" data-ins="${v}">${v}</button>`).join('')}</div>
                <div class="fm-result"></div>
              </div>`).join('')}
          </div>
          <div class="btn-row">
            <button class="btn small" id="fmSave">Save formulas</button>
            <button class="btn ghost small" id="fmRecalc">Recalculate existing entries</button>
            <button class="btn ghost small" id="fmResetAll">Reset all to default</button>
          </div>
          <p class="hint" style="color:var(--text-dim);font-size:.75rem;margin-top:8px">
            Net Quantity / Buy Total / Sell Total are stored on each entry when saved — after changing them, use
            <b>Recalculate existing entries</b> so old records follow the new formula. Profit, ROI, averages and holdings update instantly.</p>
        </div>

        <div class="panel">
          <h3>✨ Glow Effect</h3>
          <div class="switch-row"><span>Enable glow</span><input type="checkbox" id="glEnabled" ${G.enabled ? 'checked' : ''}></div>
          <div class="field" style="margin-top:10px"><label>Glow color</label><input type="color" id="glColor" value="${G.color}"></div>
          <div class="field" style="margin-top:10px"><label>Intensity: <span id="glIntVal">${G.intensity}</span></label>
            <input type="range" min="5" max="100" id="glIntensity" value="${G.intensity}"></div>
          ${[['cards', 'Cards & panels'], ['buttons', 'Buttons & menu highlight'], ['logo', 'Logo'], ['titles', 'Headings & numbers'], ['sidebar', 'Sidebar'], ['pulse', 'Pulse animation']].map(([k, l]) => `
            <div class="switch-row"><span>${l}</span><input type="checkbox" data-glow="${k}" ${G[k] ? 'checked' : ''}></div>`).join('')}
        </div>

        <div class="panel">
          <h3>🪙 Background Icons</h3>
          <div class="switch-row"><span>Flying USDT &amp; Bitcoin icons</span><input type="checkbox" id="bgEnabled" ${B.enabled ? 'checked' : ''}></div>
          <div class="field" style="margin-top:10px"><label>Icons</label>
            <select id="bgSet"><option value="both">USDT + Bitcoin</option><option value="usdt">USDT only</option><option value="btc">Bitcoin only</option></select></div>
          <div class="field" style="margin-top:10px"><label>Amount: <span id="bgCountVal">${B.count}</span></label>
            <input type="range" min="4" max="40" id="bgCount" value="${B.count}"></div>
          <div class="field" style="margin-top:10px"><label>Speed: <span id="bgSpeedVal">${B.speed}</span></label>
            <input type="range" min="1" max="10" id="bgSpeed" value="${B.speed}"></div>
          <div class="field" style="margin-top:10px"><label>Visibility: <span id="bgOpVal">${B.opacity}%</span></label>
            <input type="range" min="5" max="60" id="bgOpacity" value="${B.opacity}"></div>
          <div class="field" style="margin-top:10px"><label>Icon size: <span id="bgSizeVal">${B.size}px</span></label>
            <input type="range" min="20" max="80" id="bgSize" value="${B.size}"></div>
        </div>

        <div class="panel">
          <h3>◧ Dashboard Cards</h3>
          <p class="hint" style="color:var(--text-dim);font-size:.78rem;margin-bottom:8px">Untick to hide · use ↑↓ to reorder.</p>
          <div class="manage-list">
            ${this.cardOrderList().map(([id, label], i, arr) => `
              <div class="manage-row">
                <input type="checkbox" data-card="${id}" ${A.hiddenCards.includes(id) ? '' : 'checked'}>
                <span>${label}</span>
                <button class="icon-btn" data-move="${id}:up" ${i === 0 ? 'disabled' : ''}>↑</button>
                <button class="icon-btn" data-move="${id}:down" ${i === arr.length - 1 ? 'disabled' : ''}>↓</button>
              </div>`).join('')}
          </div>
        </div>

        <div class="panel">
          <h3>≡ Reports &amp; Sections</h3>
          ${['profit', 'tax'].map(r => `
            <div class="switch-row"><span>${r === 'profit' ? 'Profit Report' : 'Tax Report'} enabled</span>
              <input type="checkbox" data-report="${r}" ${A.disabledReports.includes(r) ? '' : 'checked'}></div>`).join('')}
        </div>

        <div class="panel">
          <h3>🔑 Security</h3>
          <div class="field"><label>Change admin password</label><input type="password" id="adNewPass" placeholder="New password"></div>
          <div class="btn-row"><button class="btn small" id="adPassSave">Change password</button></div>
        </div>

        <div class="panel">
          <h3>💾 Settings &amp; Data</h3>
          <div class="btn-row" style="margin-top:0">
            <button class="btn ghost small" id="adExpSettings">Export settings</button>
            <button class="btn ghost small" id="adImpSettings">Import settings…</button>
            <input type="file" id="adSettingsFile" accept=".json" hidden>
            <button class="btn ghost small" id="adBackup">Backup all data</button>
            <button class="btn danger small" id="adReset">Reset local storage</button>
          </div>
        </div>

        <div class="panel">
          <h3>🕓 Audit Log &amp; Timeline</h3>
          <div class="timeline">
            ${Store.data.audit.slice(0, 60).map(a => `
              <div class="timeline-item">
                <span class="dim">${new Date(a.ts).toLocaleString()}</span>
                <span><b>${U.esc(a.action)}</b> — ${U.esc(a.detail || '')}</span>
              </div>`).join('') || '<div class="empty-state">No activity yet</div>'}
          </div>
        </div>
      </div>`;

    this.bind(root);
  },

  cardOrderList() {
    const A = Store.admin();
    const defs = Dashboard.CARD_DEFS.map(d => [d[0], d[1]]);
    if (!A.cardOrder.length) return defs;
    return [...defs].sort((a, b) => {
      const ia = A.cardOrder.indexOf(a[0]), ib = A.cardOrder.indexOf(b[0]);
      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
    });
  },

  renderLock(root) {
    root.innerHTML = `
      <div class="page-head"><h2 class="page-title">Admin Panel</h2></div>
      <div class="panel" style="max-width:420px">
        <h3>🔒 Locked</h3>
        <div class="field"><label>Password</label><input type="password" id="adPass" placeholder="Default: admin"></div>
        <div class="btn-row"><button class="btn" id="adUnlock">Unlock</button></div>
      </div>`;
    const tryUnlock = () => {
      if (document.getElementById('adPass').value === Store.admin().password) {
        this.unlocked = true;
        Store.log('admin', 'Panel unlocked');
        this.render();
      } else U.toast('Wrong password', true);
    };
    document.getElementById('adUnlock').onclick = tryUnlock;
    document.getElementById('adPass').addEventListener('keydown', e => e.key === 'Enter' && tryUnlock());
  },

  bind(root) {
    const A = Store.admin();
    const L = Store.lists();
    const $ = id => document.getElementById(id);

    $('adLock').onclick = () => { this.unlocked = false; this.render(); };

    /* list add/edit/delete/fav */
    root.querySelectorAll('[data-add]').forEach(b => b.onclick = () => {
      const key = b.dataset.add;
      const input = $('add-' + key);
      const v = input.value.trim();
      if (!v) return;
      if (L[key].includes(v)) return U.toast('Already exists', true);
      History.snapshot('Add ' + key);
      L[key].push(v);
      Store.log('admin', `Added ${v} to ${key}`);
      Store.save();
      this.render();
    });
    root.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => {
      const [key, i] = b.dataset.edit.split(':');
      const old = L[key][i];
      const v = prompt('Rename "' + old + '" to:', old);
      if (!v || !v.trim() || v === old) return;
      History.snapshot('Rename in ' + key);
      L[key][i] = v.trim();
      // propagate rename into existing transactions
      const field = { assets: 'asset', banks: 'bank', modes: 'mode', expenseCategories: 'category' }[key];
      [...Store.buys(), ...Store.sells(), ...(field === 'category' ? Store.expenses() : [])]
        .forEach(t => { if (t[field] === old) t[field] = v.trim(); });
      Store.log('admin', `Renamed ${old} → ${v.trim()}`);
      Store.save();
      this.render();
    });
    root.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
      const [key, i] = b.dataset.del.split(':');
      const item = L[key][i];
      if (!await U.confirm(`Delete "${item}" from ${key}? Existing transactions keep their value.`)) return;
      History.snapshot('Delete from ' + key);
      L[key].splice(i, 1);
      Store.log('admin', `Deleted ${item} from ${key}`);
      Store.save();
      this.render();
    });
    root.querySelectorAll('[data-fav]').forEach(b => b.onclick = () => {
      const [key, i] = b.dataset.fav.split(':');
      const item = L[key][i];
      const favList = key === 'banks' ? L.favBanks : L.favAssets;
      const at = favList.indexOf(item);
      at === -1 ? favList.push(item) : favList.splice(at, 1);
      Store.save();
      this.render();
    });

    /* calculation formulas */
    const rows = [...root.querySelectorAll('.fm-row')];
    const checkRow = row => {
      const id = row.dataset.fm, input = row.querySelector('.fm-input');
      const r = Formulas.validate(id, input.value);
      const out = row.querySelector('.fm-result');
      input.classList.toggle('invalid', !r.ok);
      out.style.color = r.ok ? 'var(--text-dim)' : 'var(--danger)';
      out.textContent = r.ok ? `Test with sample data → ${U.fmtNum(r.value, 4)}` : '⚠ ' + r.error;
      row.querySelector('.fm-badge').hidden = input.value.replace(/\s+/g, '') === Formulas.DEFS[id].expr.replace(/\s+/g, '');
      return r.ok;
    };
    rows.forEach(row => {
      const input = row.querySelector('.fm-input');
      input.addEventListener('input', () => checkRow(row));
      row.querySelectorAll('[data-ins]').forEach(b => b.onclick = () => {
        const st = input.selectionStart ?? input.value.length, en = input.selectionEnd ?? st;
        input.value = input.value.slice(0, st) + b.dataset.ins + input.value.slice(en);
        input.focus(); input.setSelectionRange(st + b.dataset.ins.length, st + b.dataset.ins.length);
        checkRow(row);
      });
      row.querySelector('[data-fm-reset]').onclick = () => { input.value = Formulas.DEFS[row.dataset.fm].expr; checkRow(row); };
      checkRow(row);
    });
    $('fmSave').onclick = () => {
      if (!rows.every(checkRow)) return U.toast('Fix the highlighted formulas first', true);
      History.snapshot('Change formulas');
      A.formulas = {};
      rows.forEach(row => {
        const id = row.dataset.fm, v = row.querySelector('.fm-input').value.trim();
        if (v.replace(/\s+/g, '') !== Formulas.DEFS[id].expr.replace(/\s+/g, '')) A.formulas[id] = v;
      });
      A.profitFormula = 'sell-buy';           // retire the legacy setting
      Store.log('admin', 'Formulas updated: ' + (Object.keys(A.formulas).join(', ') || 'all default'));
      Store.save();
      App.refreshAll();
      U.toast('Formulas saved');
    };
    $('fmRecalc').onclick = async () => {
      if (!await U.confirm('Re-apply the current formulas to every existing Buy and Sell entry (Net Qty and Totals)? Undo (Ctrl+Z) can revert this.', 'Recalculate')) return;
      History.snapshot('Recalculate entries');
      const n = Formulas.recalcAll();
      Store.log('admin', `Recalculated ${n} entries`);
      Store.save();
      App.refreshAll();
      U.toast(`Recalculated ${n} entries`);
    };
    $('fmResetAll').onclick = async () => {
      if (!await U.confirm('Reset every formula back to its default?', 'Reset')) return;
      History.snapshot('Reset formulas');
      A.formulas = {}; A.profitFormula = 'sell-buy';
      Store.save(); App.refreshAll(); this.render();
      U.toast('Formulas reset');
    };

    /* glow & background icons (apply live) */
    const fx = (kind, key, val) => { Effects.cfg(kind)[key] = val; Store.save(); Effects.apply(); };
    $('glEnabled').onchange = e => fx('glow', 'enabled', e.target.checked);
    $('glColor').oninput = e => fx('glow', 'color', e.target.value);
    $('glIntensity').oninput = e => { $('glIntVal').textContent = e.target.value; fx('glow', 'intensity', +e.target.value); };
    root.querySelectorAll('[data-glow]').forEach(cb => cb.onchange = () => fx('glow', cb.dataset.glow, cb.checked));
    $('bgEnabled').onchange = e => fx('bgIcons', 'enabled', e.target.checked);
    $('bgSet').value = B.set;
    $('bgSet').onchange = e => fx('bgIcons', 'set', e.target.value);
    [['bgCount', 'count', 'bgCountVal', ''], ['bgSpeed', 'speed', 'bgSpeedVal', ''], ['bgOpacity', 'opacity', 'bgOpVal', '%'], ['bgSize', 'size', 'bgSizeVal', 'px']]
      .forEach(([id, key, label, unit]) => $(id).oninput = e => { $(label).textContent = e.target.value + unit; fx('bgIcons', key, +e.target.value); });

    /* dashboard cards */
    root.querySelectorAll('[data-card]').forEach(cb => cb.onchange = () => {
      const id = cb.dataset.card;
      const hid = A.hiddenCards;
      cb.checked ? hid.splice(hid.indexOf(id), 1) : hid.push(id);
      Store.save();
      Dashboard.refresh();
    });
    root.querySelectorAll('[data-move]').forEach(b => b.onclick = () => {
      const [id, dir] = b.dataset.move.split(':');
      let order = A.cardOrder.length ? A.cardOrder : Dashboard.CARD_DEFS.map(d => d[0]);
      const i = order.indexOf(id);
      const j = dir === 'up' ? i - 1 : i + 1;
      if (j < 0 || j >= order.length) return;
      [order[i], order[j]] = [order[j], order[i]];
      A.cardOrder = order;
      Store.save();
      this.render();
      Dashboard.refresh();
    });

    /* reports */
    root.querySelectorAll('[data-report]').forEach(cb => cb.onchange = () => {
      const r = cb.dataset.report;
      const d = A.disabledReports;
      cb.checked ? d.splice(d.indexOf(r), 1) : d.push(r);
      Store.save();
      U.toast((cb.checked ? 'Enabled ' : 'Disabled ') + r + ' report');
    });

    /* password */
    $('adPassSave').onclick = () => {
      const v = $('adNewPass').value;
      if (v.length < 4) return U.toast('Use at least 4 characters', true);
      A.password = v;
      Store.log('admin', 'Password changed');
      Store.save();
      $('adNewPass').value = '';
      U.toast('Password changed');
    };

    /* settings import/export, backup, reset */
    $('adExpSettings').onclick = () => {
      U.download('p2p-ledger-settings.json',
        JSON.stringify({ settings: Store.settings(), lists: L, admin: { ...A, password: undefined } }, null, 2),
        'application/json');
      U.toast('Settings exported (password not included)');
    };
    $('adImpSettings').onclick = () => $('adSettingsFile').click();
    $('adSettingsFile').onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      try {
        const obj = JSON.parse(await f.text());
        History.snapshot('Import settings');
        if (obj.settings) Object.assign(Store.settings(), obj.settings);
        if (obj.lists) Object.assign(L, obj.lists);
        if (obj.admin) Object.assign(A, { ...obj.admin, password: A.password });
        Store.save();
        Settings.applyAll();
        App.refreshAll();
        U.toast('Settings imported');
      } catch { U.toast('Invalid settings file', true); }
      e.target.value = '';
    };
    $('adBackup').onclick = () => {
      U.download(`p2p-ledger-backup-${U.todayISO()}.json`, Store.exportData(), 'application/json');
      U.toast('Backup downloaded');
    };
    $('adReset').onclick = async () => {
      if (!await U.confirm('Reset EVERYTHING — all transactions, expenses, settings? Download a backup first!')) return;
      if (!await U.confirm('Final confirmation: this permanently wipes local storage.')) return;
      Store.resetAll();
      Settings.applyAll();
      this.unlocked = false;
      App.refreshAll();
      U.toast('All data reset');
    };
  },
};
