# AlfynX P2P Ledger — Offline USDT Portfolio & Accounting

A 100% offline single-page app (HTML + CSS + vanilla JS) for tracking P2P
USDT/crypto buy-sell trades, expenses, profits and tax reports.
All data lives permanently in your browser's localStorage.

## How to run
1. Unzip the folder anywhere.
2. Double-click `index.html` (any modern browser: Chrome, Edge, Firefox, Brave).
3. That's it — no server, no install.

## Fully-offline charts & Excel (one-time step)
The app itself works with zero internet. Two optional libraries are loaded
from a CDN for charts and .xlsx import/export:
- Chart.js → https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.js
- SheetJS  → https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js

Download each file once, save them next to `index.html` as `chart.umd.js`
and `xlsx.full.min.js`, and change the two `<script src=...>` lines at the
top of `index.html` to point at the local files. After that, everything —
including all 10 charts and Excel import/export — works with no internet at all.
(CSV import/export and all accounting features already work without these libs.)

## Quick reference
- Admin Panel default password: **admin** (change it in Admin → Security)
- Keyboard shortcuts: Ctrl+N new buy · Ctrl+K search · Ctrl+Z / Ctrl+Shift+Z undo/redo ·
  Ctrl+B calculator · Ctrl+M notes · keys 1–0 jump between pages
- Backups: Import/Export → "Download backup" (single JSON file with everything)
- Profit formula: Admin Panel → Profit Formula (Sell−Buy, Sell−(Buy+Fees), or custom builder)
- Financial year (Apr–Mar) tax reports: Tax Reports page, export Excel/CSV or print to PDF

## Files
index.html · style.css · js/{app,storage,utils,charts,buy,sell,expenses,profit,summary,tax,dashboard,excel,settings,admin}.js

## New in this version
- **AlfynX branding** — logo in sidebar, browser tab icon, iPhone home-screen icon, printed report header
- **Binance Order Number** on Buy and Sell (form, table, search, Excel import/export, duplicate detection)
- **Admin → Calculation Formulas** — edit Net Qty, Buy Total, Sell Total, Fee Value, Gross Profit, Net Profit, ROI, Holdings, Avg Buy/Sell price.
  After changing Net Qty / Buy Total / Sell Total press "Recalculate existing entries".
- **Admin → Glow Effect** — colour, intensity, and which parts glow (cards, buttons, logo, headings, sidebar, pulse)
- **Admin → Background Icons** — flying USDT / Bitcoin icons: amount, speed, visibility, size

Files: index.html · style.css · logo.jpg · logo-icon.png · js/{app,storage,utils,formulas,charts,effects,buy,sell,expenses,profit,summary,tax,dashboard,excel,settings,admin}.js
